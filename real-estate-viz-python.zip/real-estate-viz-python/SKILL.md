---
name: real-estate-viz-python
description: Create professional real estate visualizations in Python using seaborn (static/publication) and plotly (interactive). Addresses UX/Data Science critiques of basic matplotlib. Use for housing data analysis (price distributions, correlations, maps). Colorblind-friendly palettes, publication-ready defaults, and modern aesthetics for both static and interactive outputs.
---

# Professional Real Estate Visualization in Python

## Overview

Transform basic matplotlib plots into modern, publication-ready visualizations for real estate data. Uses seaborn for beautiful static plots and plotly for interactive exploration. Addresses professional critiques with colorblind-friendly palettes and clean aesthetics

## The Problem with Basic Matplotlib

Basic matplotlib produces functional but dated visualizations:
- Default colors not colorblind-friendly
- Dense, cluttered aesthetics
- Manual styling required for professional output
- No interactive exploration
- Time-consuming customization

**This skill provides:** Modern, publication-ready alternatives using seaborn (static) and plotly (interactive).

## Required Libraries

```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go

# Set seaborn style globally
sns.set_theme(style="whitegrid", palette="colorblind")
```

## Quick Decision: Static vs Interactive

**Use seaborn when:**
- Creating plots for papers/reports (PDF, print)
- Need publication-quality static images
- Working with statistical visualizations
- Exporting to PNG/PDF for presentations

**Use plotly when:**
- Presenting to stakeholders (live demos)
- Exploratory data analysis
- Need zoom/hover/filter interactions
- Sharing interactive HTML reports

## Seaborn: Publication-Ready Static Plots

### Price Distribution

**Before (matplotlib):**
```python
plt.hist(housing['SalePrice'], bins=30)
plt.xlabel('Sale Price')
plt.ylabel('Frequency')
plt.show()
```

**After (seaborn):**
```python
import seaborn as sns
import matplotlib.pyplot as plt

fig, ax = plt.subplots(figsize=(10, 6))
sns.histplot(data=housing, x='SalePrice', bins=30, kde=True,
             color='steelblue', alpha=0.6, ax=ax)
ax.set_xlabel('Sale Price ($)', fontsize=12)
ax.set_ylabel('Frequency', fontsize=12)
ax.set_title('Distribution of Sale Prices', fontsize=14, fontweight='bold')
ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x:,.0f}'))
plt.tight_layout()
plt.show()
```

### Scatter Plot with Regression Line

**Before (matplotlib):**
```python
plt.scatter(housing['GrLivArea'], housing['SalePrice'])
plt.xlabel('Living Area')
plt.ylabel('Sale Price')
plt.show()
```

**After (seaborn):**
```python
fig, ax = plt.subplots(figsize=(10, 6))
sns.regplot(data=housing, x='GrLivArea', y='SalePrice',
            scatter_kws={'alpha': 0.5, 's': 30},
            line_kws={'color': 'red', 'linewidth': 2},
            ax=ax)
ax.set_xlabel('Above Grade Living Area (sq ft)', fontsize=12)
ax.set_ylabel('Sale Price ($)', fontsize=12)
ax.set_title('Sale Price vs. Living Area', fontsize=14, fontweight='bold')
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x:,.0f}'))
plt.tight_layout()
plt.show()
```

### Correlation Heatmap

```python
# Select numeric variables
numeric_vars = ['SalePrice', 'GrLivArea', 'OverallQual',
                'YearBuilt', 'TotalBsmtSF', 'GarageArea']
corr_matrix = housing[numeric_vars].corr()

# Create heatmap
fig, ax = plt.subplots(figsize=(10, 8))
sns.heatmap(corr_matrix, annot=True, fmt='.2f', cmap='coolwarm',
            center=0, square=True, linewidths=1,
            cbar_kws={'label': 'Correlation'}, ax=ax)
ax.set_title('Correlation Matrix: Housing Variables',
             fontsize=14, fontweight='bold', pad=20)
plt.tight_layout()
plt.show()
```

### Boxplot by Category

```python
fig, ax = plt.subplots(figsize=(12, 6))
sns.boxplot(data=housing, x='OverallQual', y='SalePrice',
            palette='Set2', ax=ax)
ax.set_xlabel('Overall Quality Rating', fontsize=12)
ax.set_ylabel('Sale Price ($)', fontsize=12)
ax.set_title('Sale Price Distribution by Quality Rating',
             fontsize=14, fontweight='bold')
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x:,.0f}'))
plt.tight_layout()
plt.show()
```

### Diagnostic Plot: Residuals vs Fitted

```python
# After fitting model
fitted = model.fittedvalues
residuals = model.resid

fig, ax = plt.subplots(figsize=(10, 6))
sns.scatterplot(x=fitted, y=residuals, alpha=0.5, color='steelblue', ax=ax)
ax.axhline(y=0, color='red', linestyle='--', linewidth=2)
ax.set_xlabel('Fitted Values', fontsize=12)
ax.set_ylabel('Residuals', fontsize=12)
ax.set_title('Residuals vs. Fitted Values', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.show()
```

## Plotly: Interactive Exploration

### Interactive Price Distribution

```python
import plotly.express as px

fig = px.histogram(housing, x='SalePrice', nbins=30,
                   title='Distribution of Sale Prices',
                   labels={'SalePrice': 'Sale Price ($)'},
                   opacity=0.7, color_discrete_sequence=['steelblue'])
fig.update_layout(
    xaxis_title='Sale Price ($)',
    yaxis_title='Frequency',
    font=dict(size=12),
    hovermode='x unified'
)
fig.show()
```

### Interactive Scatter with Hover Info

```python
fig = px.scatter(housing, x='GrLivArea', y='SalePrice',
                 hover_data=['OverallQual', 'YearBuilt', 'Neighborhood'],
                 title='Sale Price vs. Living Area',
                 labels={'GrLivArea': 'Above Grade Living Area (sq ft)',
                        'SalePrice': 'Sale Price ($)'},
                 opacity=0.6, color='OverallQual',
                 color_continuous_scale='viridis')
fig.update_layout(
    font=dict(size=12),
    hovermode='closest'
)
fig.show()
```

### Interactive Correlation Heatmap

```python
import plotly.graph_objects as go

numeric_vars = ['SalePrice', 'GrLivArea', 'OverallQual',
                'YearBuilt', 'TotalBsmtSF', 'GarageArea']
corr_matrix = housing[numeric_vars].corr()

fig = go.Figure(data=go.Heatmap(
    z=corr_matrix.values,
    x=corr_matrix.columns,
    y=corr_matrix.columns,
    colorscale='RdBu',
    zmid=0,
    text=corr_matrix.values.round(2),
    texttemplate='%{text}',
    textfont={"size": 10},
    colorbar=dict(title="Correlation")
))
fig.update_layout(
    title='Correlation Matrix: Housing Variables',
    font=dict(size=12),
    width=700,
    height=600
)
fig.show()
```

### Interactive Boxplot by Category

```python
fig = px.box(housing, x='OverallQual', y='SalePrice',
             title='Sale Price Distribution by Quality Rating',
             labels={'OverallQual': 'Overall Quality Rating',
                    'SalePrice': 'Sale Price ($)'},
             color='OverallQual',
             color_discrete_sequence=px.colors.qualitative.Set2)
fig.update_layout(
    showlegend=False,
    font=dict(size=12),
    hovermode='x unified'
)
fig.show()
```

## Colorblind-Friendly Palettes

### Seaborn Palettes
```python
# Set globally
sns.set_palette("colorblind")

# Or per plot
sns.histplot(data=housing, x='SalePrice',
             color=sns.color_palette("colorblind")[0])

# Recommended palettes
# - "colorblind" (default safe choice)
# - "Set2" (categorical data)
# - "coolwarm" (diverging data, centered at zero)
# - "viridis" (sequential data)
```

### Plotly Palettes
```python
# Categorical
color_discrete_sequence=px.colors.qualitative.Safe

# Sequential
color_continuous_scale='viridis'

# Diverging
color_continuous_scale='RdBu'
```

## Code Formatting for Quarto

### Seaborn in Quarto
````markdown
```{python}
#| label: fig-price-dist
#| fig-cap: "Distribution of sale prices in Ames housing dataset"

import seaborn as sns
import matplotlib.pyplot as plt

fig, ax = plt.subplots(figsize=(10, 6))
sns.histplot(data=housing, x='SalePrice', bins=30, kde=True, ax=ax)
ax.set_title('Sale Price Distribution')
plt.show()
```
````

### Plotly in Quarto
````markdown
```{python}
#| label: fig-interactive-scatter
#| fig-cap: "Interactive scatter plot of price vs living area"

import plotly.express as px

fig = px.scatter(housing, x='GrLivArea', y='SalePrice',
                 hover_data=['OverallQual', 'Neighborhood'])
fig.show()
```
````

## Common Styling Tips

### Seaborn Global Settings
```python
# Set theme for entire notebook
sns.set_theme(
    style="whitegrid",        # Clean background
    palette="colorblind",     # Accessible colors
    font_scale=1.2,          # Larger text
    rc={
        'figure.figsize': (10, 6),
        'axes.labelsize': 12,
        'axes.titlesize': 14,
        'xtick.labelsize': 10,
        'ytick.labelsize': 10
    }
)
```

### Plotly Templates
```python
# Set template for entire notebook
import plotly.io as pio
pio.templates.default = "plotly_white"

# Or per plot
fig.update_layout(template="plotly_white")

# Recommended templates: "plotly_white", "simple_white", "ggplot2"
```

## Resources

This skill includes reference documentation for seaborn and plotly:

### references/seaborn_guide.md
Comprehensive seaborn reference with plot types, styling options, and real estate examples.

### references/plotly_guide.md
Plotly Express and Graph Objects guide with interactive visualization patterns.

### references/python_viz_examples.md
Complete before/after examples for all common real estate visualization tasks.

## Integration

- **housing-analysis-python**: Statistical analysis (pandas, statsmodels, scikit-learn)
- **real-estate-viz-python**: Professional visualization (this skill)

Use housing-analysis-python for regression analysis, then create publication-ready plots with this skill.
