# Complete Python Visualization Examples for Real Estate

## Setup

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go

# Load data
housing = pd.read_csv('amesHousing2011.csv')

# Set seaborn defaults
sns.set_theme(style="whitegrid", palette="colorblind", font_scale=1.1)
```

## 1. Price Distribution

### Basic Matplotlib (Before)
```python
plt.figure(figsize=(10, 6))
plt.hist(housing['SalePrice'], bins=30, color='blue')
plt.xlabel('Sale Price')
plt.ylabel('Frequency')
plt.title('Distribution of Sale Prices')
plt.show()
```

### Seaborn (After - Static)
```python
fig, ax = plt.subplots(figsize=(10, 6))
sns.histplot(data=housing, x='SalePrice', bins=30, kde=True,
             color='steelblue', alpha=0.6, ax=ax)
ax.set_xlabel('Sale Price ($)', fontsize=12)
ax.set_ylabel('Frequency', fontsize=12)
ax.set_title('Distribution of Sale Prices', fontsize=14, fontweight='bold')
ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x:,.0f}'))
plt.tight_layout()
plt.show()
```

### Plotly (After - Interactive)
```python
fig = px.histogram(housing, x='SalePrice', nbins=30,
                   title='Distribution of Sale Prices',
                   labels={'SalePrice': 'Sale Price ($)'},
                   opacity=0.7, color_discrete_sequence=['steelblue'])
fig.update_layout(
    xaxis_title='Sale Price ($)',
    yaxis_title='Frequency',
    font=dict(size=12),
    hovermode='x unified',
    template='plotly_white'
)
fig.show()
```

## 2. Scatter Plot: Price vs Living Area

### Basic Matplotlib (Before)
```python
plt.figure(figsize=(10, 6))
plt.scatter(housing['GrLivArea'], housing['SalePrice'], alpha=0.5)
plt.xlabel('Living Area (sq ft)')
plt.ylabel('Sale Price')
plt.title('Sale Price vs. Living Area')
plt.show()
```

### Seaborn (After - Static)
```python
fig, ax = plt.subplots(figsize=(10, 6))
sns.regplot(data=housing, x='GrLivArea', y='SalePrice',
            scatter_kws={'alpha': 0.5, 's': 30, 'color': 'steelblue'},
            line_kws={'color': 'red', 'linewidth': 2},
            ax=ax)
ax.set_xlabel('Above Grade Living Area (sq ft)', fontsize=12)
ax.set_ylabel('Sale Price ($)', fontsize=12)
ax.set_title('Sale Price vs. Living Area with Regression Line',
             fontsize=14, fontweight='bold')
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x:,.0f}'))

# Add correlation
from scipy import stats
r, p = stats.pearsonr(housing['GrLivArea'], housing['SalePrice'])
ax.text(0.05, 0.95, f'r = {r:.3f}\np < 0.001',
        transform=ax.transAxes, va='top',
        bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))

plt.tight_layout()
plt.show()
```

### Plotly (After - Interactive)
```python
fig = px.scatter(housing, x='GrLivArea', y='SalePrice',
                 hover_data=['OverallQual', 'YearBuilt', 'Neighborhood'],
                 title='Sale Price vs. Living Area',
                 labels={'GrLivArea': 'Above Grade Living Area (sq ft)',
                        'SalePrice': 'Sale Price ($)'},
                 opacity=0.6, color='OverallQual',
                 color_continuous_scale='viridis',
                 trendline='ols')
fig.update_layout(
    font=dict(size=12),
    hovermode='closest',
    template='plotly_white'
)
fig.show()
```

## 3. Correlation Heatmap

### Basic Matplotlib (Before)
```python
numeric_vars = ['SalePrice', 'GrLivArea', 'OverallQual',
                'YearBuilt', 'TotalBsmtSF', 'GarageArea']
corr_matrix = housing[numeric_vars].corr()

plt.figure(figsize=(10, 8))
plt.imshow(corr_matrix, cmap='coolwarm', aspect='auto')
plt.colorbar()
plt.xticks(range(len(corr_matrix)), corr_matrix.columns, rotation=45)
plt.yticks(range(len(corr_matrix)), corr_matrix.columns)
plt.title('Correlation Matrix')
plt.show()
```

### Seaborn (After - Static)
```python
numeric_vars = ['SalePrice', 'GrLivArea', 'OverallQual',
                'YearBuilt', 'TotalBsmtSF', 'GarageArea']
corr_matrix = housing[numeric_vars].corr()

fig, ax = plt.subplots(figsize=(10, 8))
sns.heatmap(corr_matrix, annot=True, fmt='.2f', cmap='coolwarm',
            center=0, square=True, linewidths=1,
            cbar_kws={'label': 'Correlation'},
            annot_kws={'size': 10}, ax=ax)
ax.set_title('Correlation Matrix: Housing Variables',
             fontsize=14, fontweight='bold', pad=20)
plt.tight_layout()
plt.show()
```

### Plotly (After - Interactive)
```python
numeric_vars = ['SalePrice', 'GrLivArea', 'OverallQual',
                'YearBuilt', 'TotalBsmtSF', 'GarageArea']
corr_matrix = housing[numeric_vars].corr()

fig = go.Figure(data=go.Heatmap(
    z=corr_matrix.values,
    x=corr_matrix.columns,
    y=corr_matrix.columns,
    colorscale='RdBu',
    zmid=0,
    text=corr_matrix.values.round(2),
    texttemplate='%{text}',
    textfont={"size": 10},
    colorbar=dict(title="Correlation"),
    hovertemplate='%{y} vs %{x}<br>Correlation: %{z:.2f}<extra></extra>'
))
fig.update_layout(
    title='Correlation Matrix: Housing Variables',
    font=dict(size=12),
    width=700,
    height=600,
    template='plotly_white'
)
fig.show()
```

## 4. Box Plot by Category

### Basic Matplotlib (Before)
```python
fig, ax = plt.subplots(figsize=(12, 6))
data_to_plot = [housing[housing['OverallQual'] == q]['SalePrice'].dropna()
                for q in sorted(housing['OverallQual'].unique())]
ax.boxplot(data_to_plot)
ax.set_xlabel('Overall Quality')
ax.set_ylabel('Sale Price')
ax.set_title('Sale Price by Quality')
plt.show()
```

### Seaborn (After - Static)
```python
fig, ax = plt.subplots(figsize=(12, 6))
sns.boxplot(data=housing, x='OverallQual', y='SalePrice',
            palette='Set2', ax=ax)
ax.set_xlabel('Overall Quality Rating', fontsize=12)
ax.set_ylabel('Sale Price ($)', fontsize=12)
ax.set_title('Sale Price Distribution by Quality Rating',
             fontsize=14, fontweight='bold')
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x:,.0f}'))

# Add sample sizes
for i, quality in enumerate(sorted(housing['OverallQual'].unique())):
    n = len(housing[housing['OverallQual'] == quality])
    ax.text(i, ax.get_ylim()[0], f'n={n}', ha='center', va='top', fontsize=9)

plt.tight_layout()
plt.show()
```

### Plotly (After - Interactive)
```python
fig = px.box(housing, x='OverallQual', y='SalePrice',
             title='Sale Price Distribution by Quality Rating',
             labels={'OverallQual': 'Overall Quality Rating',
                    'SalePrice': 'Sale Price ($)'},
             color='OverallQual',
             color_discrete_sequence=px.colors.qualitative.Set2,
             points='outliers')
fig.update_layout(
    showlegend=False,
    font=dict(size=12),
    hovermode='x unified',
    template='plotly_white'
)
fig.show()
```

## 5. Multiple Predictor Visualization

### Seaborn Pairplot
```python
vars_to_plot = ['SalePrice', 'GrLivArea', 'OverallQual',
                'YearBuilt', 'TotalBsmtSF']

g = sns.pairplot(housing[vars_to_plot],
                 diag_kind='kde',
                 plot_kws={'alpha': 0.6, 's': 30},
                 diag_kws={'alpha': 0.7})
g.fig.suptitle('Pairwise Relationships: Housing Variables',
               y=1.02, fontsize=14, fontweight='bold')
plt.show()
```

### Plotly Parallel Coordinates
```python
# Normalize for better visualization
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()

vars_to_plot = ['SalePrice', 'GrLivArea', 'OverallQual',
                'YearBuilt', 'TotalBsmtSF', 'GarageArea']
housing_scaled = housing[vars_to_plot].copy()
housing_scaled[vars_to_plot] = scaler.fit_transform(housing_scaled[vars_to_plot])

fig = px.parallel_coordinates(
    housing_scaled,
    dimensions=vars_to_plot,
    color='SalePrice',
    color_continuous_scale='viridis',
    title='Parallel Coordinates: Housing Variables (Normalized)'
)
fig.update_layout(
    font=dict(size=12),
    template='plotly_white'
)
fig.show()
```

## 6. Diagnostic Plots

### Residuals vs Fitted (Seaborn)
```python
# Assuming you have a fitted model
import statsmodels.formula.api as smf

model = smf.ols('SalePrice ~ GrLivArea + OverallQual', data=housing).fit()
fitted = model.fittedvalues
residuals = model.resid

fig, ax = plt.subplots(figsize=(10, 6))
sns.scatterplot(x=fitted, y=residuals, alpha=0.5, color='steelblue', ax=ax)
ax.axhline(y=0, color='red', linestyle='--', linewidth=2)
ax.set_xlabel('Fitted Values', fontsize=12)
ax.set_ylabel('Residuals', fontsize=12)
ax.set_title('Residuals vs. Fitted Values', fontsize=14, fontweight='bold')

# Add lowess smoother
from statsmodels.nonparametric.smoothers_lowess import lowess
lowess_fit = lowess(residuals, fitted, frac=0.3)
ax.plot(lowess_fit[:, 0], lowess_fit[:, 1], color='orange',
        linewidth=2, label='LOWESS')
ax.legend()

plt.tight_layout()
plt.show()
```

### Q-Q Plot (Seaborn)
```python
from scipy import stats

fig, ax = plt.subplots(figsize=(8, 8))
stats.probplot(residuals, dist="norm", plot=ax)
ax.set_title('Normal Q-Q Plot', fontsize=14, fontweight='bold')
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()
```

## 7. Neighborhood Comparison

### Seaborn Categorical Plot
```python
# Top 10 neighborhoods by count
top_neighborhoods = housing['Neighborhood'].value_counts().head(10).index
housing_top = housing[housing['Neighborhood'].isin(top_neighborhoods)]

fig, ax = plt.subplots(figsize=(14, 8))
sns.boxplot(data=housing_top, x='Neighborhood', y='SalePrice',
            palette='Set2', ax=ax)
ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right')
ax.set_ylabel('Sale Price ($)', fontsize=12)
ax.set_xlabel('Neighborhood', fontsize=12)
ax.set_title('Sale Price Distribution by Neighborhood (Top 10)',
             fontsize=14, fontweight='bold')
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x:,.0f}'))
plt.tight_layout()
plt.show()
```

### Plotly Bar Chart with Error Bars
```python
neighborhood_stats = housing.groupby('Neighborhood')['SalePrice'].agg(['mean', 'std']).reset_index()
neighborhood_stats = neighborhood_stats.sort_values('mean', ascending=False).head(10)

fig = px.bar(neighborhood_stats, x='Neighborhood', y='mean',
             error_y='std',
             title='Average Sale Price by Neighborhood (Top 10)',
             labels={'mean': 'Average Sale Price ($)', 'Neighborhood': 'Neighborhood'},
             color='mean',
             color_continuous_scale='viridis')
fig.update_layout(
    font=dict(size=12),
    template='plotly_white',
    xaxis_tickangle=-45,
    showlegend=False
)
fig.show()
```

## 8. Complete Exploratory Analysis Template

```python
def explore_housing_data(df):
    """
    Complete exploratory visualization suite for housing data
    """
    # Set seaborn style
    sns.set_theme(style="whitegrid", palette="colorblind", font_scale=1.1)

    # Create figure with subplots
    fig = plt.figure(figsize=(16, 12))

    # 1. Price distribution
    ax1 = plt.subplot(2, 3, 1)
    sns.histplot(data=df, x='SalePrice', bins=30, kde=True, ax=ax1)
    ax1.set_title('Price Distribution', fontweight='bold')
    ax1.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x/1000:.0f}K'))

    # 2. Price vs Living Area
    ax2 = plt.subplot(2, 3, 2)
    sns.regplot(data=df, x='GrLivArea', y='SalePrice',
                scatter_kws={'alpha': 0.5}, ax=ax2)
    ax2.set_title('Price vs Living Area', fontweight='bold')
    ax2.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x/1000:.0f}K'))

    # 3. Quality distribution
    ax3 = plt.subplot(2, 3, 3)
    sns.boxplot(data=df, x='OverallQual', y='SalePrice', ax=ax3)
    ax3.set_title('Price by Quality', fontweight='bold')
    ax3.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x/1000:.0f}K'))

    # 4. Correlation heatmap
    ax4 = plt.subplot(2, 3, 4)
    numeric_vars = ['SalePrice', 'GrLivArea', 'OverallQual', 'YearBuilt']
    corr = df[numeric_vars].corr()
    sns.heatmap(corr, annot=True, fmt='.2f', cmap='coolwarm',
                center=0, square=True, ax=ax4)
    ax4.set_title('Correlation Matrix', fontweight='bold')

    # 5. Year built effect
    ax5 = plt.subplot(2, 3, 5)
    year_avg = df.groupby('YearBuilt')['SalePrice'].mean()
    ax5.plot(year_avg.index, year_avg.values, linewidth=2)
    ax5.set_title('Average Price by Year Built', fontweight='bold')
    ax5.set_xlabel('Year Built')
    ax5.set_ylabel('Average Sale Price')
    ax5.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x/1000:.0f}K'))

    # 6. Summary statistics
    ax6 = plt.subplot(2, 3, 6)
    ax6.axis('off')
    stats_text = f"""
    Dataset Summary:

    Total Properties: {len(df):,}
    Mean Price: ${df['SalePrice'].mean():,.0f}
    Median Price: ${df['SalePrice'].median():,.0f}
    Std Dev: ${df['SalePrice'].std():,.0f}

    Price Range:
    Min: ${df['SalePrice'].min():,.0f}
    Max: ${df['SalePrice'].max():,.0f}

    Living Area Range:
    Min: {df['GrLivArea'].min():,.0f} sq ft
    Max: {df['GrLivArea'].max():,.0f} sq ft
    """
    ax6.text(0.1, 0.9, stats_text, transform=ax6.transAxes,
             fontsize=10, verticalalignment='top',
             fontfamily='monospace',
             bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.3))

    plt.tight_layout()
    plt.show()

# Use the function
explore_housing_data(housing)
```
