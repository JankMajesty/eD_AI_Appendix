# Seaborn Guide for Real Estate Visualizations

## Core Plot Types

### Distribution Plots

**histplot** - Histogram with optional KDE
```python
sns.histplot(data=housing, x='SalePrice', bins=30, kde=True,
             color='steelblue', alpha=0.6)
```

**kdeplot** - Kernel density estimation
```python
sns.kdeplot(data=housing, x='SalePrice', fill=True, alpha=0.5)
```

**displot** - Figure-level distribution (combines hist + kde)
```python
sns.displot(data=housing, x='SalePrice', kind='hist', kde=True,
            height=6, aspect=1.5)
```

### Relationship Plots

**scatterplot** - Basic scatter
```python
sns.scatterplot(data=housing, x='GrLivArea', y='SalePrice',
                hue='OverallQual', alpha=0.6)
```

**regplot** - Scatter with regression line
```python
sns.regplot(data=housing, x='GrLivArea', y='SalePrice',
            scatter_kws={'alpha': 0.5},
            line_kws={'color': 'red'})
```

**lmplot** - Figure-level regression plot
```python
sns.lmplot(data=housing, x='GrLivArea', y='SalePrice',
           hue='OverallQual', height=6)
```

### Categorical Plots

**boxplot** - Box and whisker plot
```python
sns.boxplot(data=housing, x='OverallQual', y='SalePrice',
            palette='Set2')
```

**violinplot** - Violin plot (distribution + boxplot)
```python
sns.violinplot(data=housing, x='OverallQual', y='SalePrice',
               palette='muted')
```

**barplot** - Mean with confidence intervals
```python
sns.barplot(data=housing, x='Neighborhood', y='SalePrice',
            errorbar='sd', palette='pastel')
```

### Matrix Plots

**heatmap** - Correlation matrix
```python
sns.heatmap(corr_matrix, annot=True, fmt='.2f',
            cmap='coolwarm', center=0, square=True)
```

**clustermap** - Hierarchical clustering heatmap
```python
sns.clustermap(corr_matrix, cmap='coolwarm', center=0,
               figsize=(10, 10))
```

## Themes and Styles

### Global Theme Settings
```python
sns.set_theme(
    style="whitegrid",      # "white", "dark", "whitegrid", "darkgrid", "ticks"
    palette="colorblind",   # Color palette
    font="sans-serif",      # Font family
    font_scale=1.2,         # Scale all fonts
    rc={                    # Additional matplotlib rcParams
        'figure.figsize': (10, 6),
        'axes.labelsize': 12,
        'axes.titlesize': 14
    }
)
```

### Available Styles
- `whitegrid` - White background with grid lines (recommended for most plots)
- `darkgrid` - Dark background with grid lines
- `white` - White background, no grid
- `dark` - Dark background, no grid
- `ticks` - White background with axis ticks

### Reset to Default
```python
sns.reset_defaults()
```

## Color Palettes

### Qualitative (categorical data)
```python
sns.set_palette("colorblind")    # 10 distinct colors
sns.set_palette("Set2")          # 8 pastel colors
sns.set_palette("Paired")        # 12 paired colors
sns.set_palette("tab10")         # Tableau 10 colors
```

### Sequential (low to high)
```python
sns.set_palette("Blues")         # Blue gradient
sns.set_palette("viridis")       # Perceptually uniform
sns.set_palette("rocket")        # Purple to yellow
sns.set_palette("mako")          # Green to blue
```

### Diverging (centered data)
```python
sns.set_palette("coolwarm")      # Blue to red
sns.set_palette("vlag")          # Blue to red (better contrast)
sns.set_palette("icefire")       # Cyan to orange
```

### Custom Palette
```python
custom_colors = ["#3498db", "#e74c3c", "#2ecc71", "#f39c12"]
sns.set_palette(custom_colors)
```

## Figure-Level vs Axes-Level

### Axes-Level (more control, can combine)
```python
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
sns.histplot(data=housing, x='SalePrice', ax=ax1)
sns.boxplot(data=housing, x='OverallQual', y='SalePrice', ax=ax2)
plt.tight_layout()
```

### Figure-Level (automatic layout)
```python
# Automatically creates figure and axes
g = sns.displot(data=housing, x='SalePrice', col='OverallQual',
                kind='hist', height=4, col_wrap=3)
g.set_titles("Quality {col_name}")
```

## Real Estate Specific Examples

### Price Distribution by Neighborhood
```python
import matplotlib.pyplot as plt

fig, ax = plt.subplots(figsize=(14, 8))
sns.boxplot(data=housing, x='Neighborhood', y='SalePrice',
            palette='Set2', ax=ax)
ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right')
ax.set_ylabel('Sale Price ($)', fontsize=12)
ax.set_xlabel('Neighborhood', fontsize=12)
ax.set_title('Sale Price Distribution by Neighborhood',
             fontsize=14, fontweight='bold')
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x:,.0f}'))
plt.tight_layout()
plt.show()
```

### Multiple Variable Relationships
```python
# Pairplot for quick exploration
sns.pairplot(housing[['SalePrice', 'GrLivArea', 'OverallQual',
                       'YearBuilt', 'TotalBsmtSF']],
             diag_kind='kde', plot_kws={'alpha': 0.6})
plt.show()
```

### Price vs Area by Quality (faceted)
```python
g = sns.lmplot(data=housing, x='GrLivArea', y='SalePrice',
               col='OverallQual', col_wrap=3,
               height=4, aspect=1.2,
               scatter_kws={'alpha': 0.5})
g.set_axis_labels("Living Area (sq ft)", "Sale Price ($)")
g.set_titles("Quality Rating: {col_name}")
plt.show()
```

## Formatting Tips

### Currency Formatting
```python
import matplotlib.pyplot as plt

ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x:,.0f}'))
ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x/1000:.0f}K'))
```

### Rotate Labels
```python
ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right')
plt.xticks(rotation=90)
```

### Remove Spines
```python
sns.despine()  # Remove top and right spines
sns.despine(left=True, bottom=True)  # Remove more spines
```

### Add Grid
```python
ax.grid(True, alpha=0.3, linestyle='--')
```

### Figure Size
```python
# Per figure
fig, ax = plt.subplots(figsize=(10, 6))

# Globally
plt.rcParams['figure.figsize'] = (10, 6)
```

## Statistical Annotations

### Add Correlation
```python
from scipy import stats

slope, intercept, r_value, p_value, std_err = stats.linregress(
    housing['GrLivArea'], housing['SalePrice'])

ax.text(0.05, 0.95, f'r = {r_value:.3f}\np < 0.001',
        transform=ax.transAxes, va='top',
        bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
```

### Confidence Intervals
```python
sns.regplot(data=housing, x='GrLivArea', y='SalePrice',
            ci=95)  # 95% confidence interval (default)
```

## Saving Figures

```python
# High resolution PNG
plt.savefig('price_distribution.png', dpi=300, bbox_inches='tight')

# PDF for publication
plt.savefig('price_distribution.pdf', bbox_inches='tight')

# Transparent background
plt.savefig('price_distribution.png', transparent=True, dpi=300)
```
