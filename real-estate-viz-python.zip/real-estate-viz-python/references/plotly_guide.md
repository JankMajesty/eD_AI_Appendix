# Plotly Guide for Real Estate Visualizations

## Plotly Express vs Graph Objects

### Plotly Express (px) - High-level, quick plots
```python
import plotly.express as px

fig = px.scatter(housing, x='GrLivArea', y='SalePrice',
                 color='OverallQual', title='Price vs Area')
fig.show()
```

### Graph Objects (go) - Low-level, more control
```python
import plotly.graph_objects as go

fig = go.Figure(data=go.Scatter(
    x=housing['GrLivArea'],
    y=housing['SalePrice'],
    mode='markers'
))
fig.update_layout(title='Price vs Area')
fig.show()
```

**Recommendation:** Start with Express, use Objects for custom needs.

## Core Plot Types

### Scatter Plots

**Basic Scatter**
```python
fig = px.scatter(housing, x='GrLivArea', y='SalePrice',
                 title='Sale Price vs Living Area')
fig.show()
```

**With Color and Size**
```python
fig = px.scatter(housing, x='GrLivArea', y='SalePrice',
                 color='OverallQual', size='TotalBsmtSF',
                 hover_data=['Neighborhood', 'YearBuilt'],
                 color_continuous_scale='viridis',
                 opacity=0.6)
fig.update_layout(title='Multi-dimensional Housing Data')
fig.show()
```

**With Trendline**
```python
fig = px.scatter(housing, x='GrLivArea', y='SalePrice',
                 trendline='ols',  # Ordinary least squares
                 title='Price vs Area with Regression')
fig.show()
```

### Histograms

**Basic Histogram**
```python
fig = px.histogram(housing, x='SalePrice', nbins=30,
                   title='Distribution of Sale Prices')
fig.show()
```

**With Marginal Plot**
```python
fig = px.histogram(housing, x='SalePrice', y='GrLivArea',
                   marginal='box',  # or 'violin', 'rug'
                   nbins=30)
fig.show()
```

**Overlaid by Category**
```python
fig = px.histogram(housing, x='SalePrice', color='OverallQual',
                   barmode='overlay', opacity=0.7,
                   nbins=30)
fig.show()
```

### Box Plots

**Basic Box Plot**
```python
fig = px.box(housing, x='OverallQual', y='SalePrice',
             title='Price Distribution by Quality')
fig.show()
```

**With Points**
```python
fig = px.box(housing, x='OverallQual', y='SalePrice',
             points='all',  # or 'outliers', 'suspectedoutliers'
             hover_data=['Neighborhood'])
fig.show()
```

### Bar Charts

**Mean with Error Bars**
```python
fig = px.bar(housing.groupby('Neighborhood')['SalePrice'].mean().reset_index(),
             x='Neighborhood', y='SalePrice',
             error_y=housing.groupby('Neighborhood')['SalePrice'].std(),
             title='Average Price by Neighborhood')
fig.show()
```

### Heatmaps

**Correlation Heatmap**
```python
import plotly.graph_objects as go

numeric_vars = ['SalePrice', 'GrLivArea', 'OverallQual', 'YearBuilt']
corr_matrix = housing[numeric_vars].corr()

fig = go.Figure(data=go.Heatmap(
    z=corr_matrix.values,
    x=corr_matrix.columns,
    y=corr_matrix.columns,
    colorscale='RdBu',
    zmid=0,
    text=corr_matrix.values.round(2),
    texttemplate='%{text}',
    textfont={"size": 10},
    colorbar=dict(title="Correlation")
))
fig.update_layout(title='Correlation Matrix',
                  width=600, height=600)
fig.show()
```

### Line Plots

**Time Series**
```python
avg_by_year = housing.groupby('YearBuilt')['SalePrice'].mean().reset_index()

fig = px.line(avg_by_year, x='YearBuilt', y='SalePrice',
              title='Average Sale Price by Year Built',
              markers=True)
fig.show()
```

## Hover Information

### Custom Hover Template
```python
fig = px.scatter(housing, x='GrLivArea', y='SalePrice')
fig.update_traces(
    hovertemplate='<b>Living Area</b>: %{x:,.0f} sq ft<br>' +
                  '<b>Sale Price</b>: $%{y:,.0f}<br>' +
                  '<extra></extra>'  # Removes trace name
)
fig.show()
```

### Add Custom Hover Data
```python
fig = px.scatter(housing, x='GrLivArea', y='SalePrice',
                 hover_data={
                     'GrLivArea': ':.0f',  # No decimals
                     'SalePrice': ':$,.0f',  # Currency format
                     'OverallQual': True,  # Show as is
                     'Neighborhood': True
                 })
fig.show()
```

## Layout Customization

### Update Layout
```python
fig.update_layout(
    title='Sale Price vs Living Area',
    title_font_size=18,
    title_x=0.5,  # Center title
    xaxis_title='Above Grade Living Area (sq ft)',
    yaxis_title='Sale Price ($)',
    font=dict(family='Arial', size=12),
    hovermode='closest',  # or 'x unified', 'y unified'
    template='plotly_white',  # Clean template
    width=800,
    height=600
)
```

### Update Axes
```python
fig.update_xaxes(
    title='Living Area (sq ft)',
    showgrid=True,
    gridwidth=1,
    gridcolor='LightGray',
    zeroline=False
)

fig.update_yaxes(
    title='Sale Price ($)',
    tickformat='$,.0f',  # Currency format
    showgrid=True
)
```

## Color Scales

### Continuous Scales
```python
# Sequential
color_continuous_scale='viridis'  # viridis, plasma, inferno, magma
color_continuous_scale='Blues'    # Any matplotlib colormap

# Diverging
color_continuous_scale='RdBu'     # Red to Blue
color_continuous_scale='PiYG'     # Pink to Green

# Custom
color_continuous_scale=[[0, 'blue'], [0.5, 'white'], [1, 'red']]
```

### Discrete Colors
```python
# Qualitative palettes
color_discrete_sequence=px.colors.qualitative.Plotly  # Default
color_discrete_sequence=px.colors.qualitative.Safe    # Colorblind-safe
color_discrete_sequence=px.colors.qualitative.Set2

# Custom
color_discrete_sequence=['#3498db', '#e74c3c', '#2ecc71']
```

## Templates

### Built-in Templates
```python
# Set default template
import plotly.io as pio
pio.templates.default = 'plotly_white'

# Per figure
fig.update_layout(template='plotly_white')

# Available templates:
# - plotly (default, dark grid)
# - plotly_white (clean, white background)
# - plotly_dark (dark theme)
# - ggplot2 (R ggplot2 style)
# - seaborn (seaborn style)
# - simple_white (minimal)
# - none (no styling)
```

## Interactive Features

### Range Slider
```python
fig.update_xaxes(rangeslider_visible=True)
```

### Dropdown Menus
```python
fig.update_layout(
    updatemenus=[
        dict(
            buttons=[
                dict(label="Linear", method="relayout",
                     args=[{"yaxis.type": "linear"}]),
                dict(label="Log", method="relayout",
                     args=[{"yaxis.type": "log"}])
            ],
            direction="down",
            x=0.1, y=1.15
        )
    ]
)
```

### Annotations
```python
fig.add_annotation(
    x=2000, y=300000,
    text="Outlier cluster",
    showarrow=True,
    arrowhead=2,
    arrowcolor='red',
    font=dict(size=12, color='red')
)
```

## Subplots

### Create Grid
```python
from plotly.subplots import make_subplots

fig = make_subplots(
    rows=2, cols=2,
    subplot_titles=('Price Distribution', 'Price vs Area',
                    'Quality Distribution', 'Correlation')
)

# Add traces
fig.add_trace(
    go.Histogram(x=housing['SalePrice'], name='Price'),
    row=1, col=1
)

fig.add_trace(
    go.Scatter(x=housing['GrLivArea'], y=housing['SalePrice'],
               mode='markers', name='Area vs Price'),
    row=1, col=2
)

fig.update_layout(height=800, showlegend=False)
fig.show()
```

## Real Estate Specific Examples

### Geographic Distribution
```python
# If you have lat/lon data
fig = px.scatter_mapbox(housing, lat='Latitude', lon='Longitude',
                        color='SalePrice', size='GrLivArea',
                        hover_data=['Neighborhood', 'OverallQual'],
                        color_continuous_scale='viridis',
                        mapbox_style='open-street-map',
                        zoom=11)
fig.show()
```

### 3D Scatter
```python
fig = px.scatter_3d(housing, x='GrLivArea', y='OverallQual', z='SalePrice',
                    color='YearBuilt',
                    hover_data=['Neighborhood'],
                    opacity=0.7)
fig.update_layout(title='Multi-dimensional Housing Analysis')
fig.show()
```

### Animation by Year
```python
fig = px.scatter(housing, x='GrLivArea', y='SalePrice',
                 animation_frame='YearBuilt',
                 animation_group='Neighborhood',
                 color='OverallQual',
                 hover_name='Neighborhood',
                 range_x=[0, 5000], range_y=[0, 600000])
fig.show()
```

### Parallel Coordinates
```python
fig = px.parallel_coordinates(
    housing[['SalePrice', 'GrLivArea', 'OverallQual', 'YearBuilt']],
    color='SalePrice',
    color_continuous_scale='viridis',
    title='Multi-variable Housing Analysis'
)
fig.show()
```

## Saving Figures

### HTML (interactive)
```python
fig.write_html('plot.html')
```

### Static Image (requires kaleido)
```python
# Install: pip install kaleido
fig.write_image('plot.png', width=1200, height=800, scale=2)
fig.write_image('plot.pdf')
fig.write_image('plot.svg')
```

## Performance Tips

### For Large Datasets
```python
# Use WebGL for faster rendering
fig = go.Figure(data=go.Scattergl(  # Note: Scattergl, not Scatter
    x=housing['GrLivArea'],
    y=housing['SalePrice'],
    mode='markers'
))
```

### Reduce File Size
```python
# Remove unnecessary data from saved HTML
fig.write_html('plot.html', include_plotlyjs='cdn')
```

## Combining with Dash

For interactive web apps:
```python
import dash
from dash import dcc, html

app = dash.Dash(__name__)

app.layout = html.Div([
    dcc.Graph(figure=fig)
])

if __name__ == '__main__':
    app.run_server(debug=True)
```
