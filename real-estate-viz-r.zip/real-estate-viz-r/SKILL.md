---
name: real-estate-viz-r
description: Create professional, publication-ready real estate data visualizations in R using ggplot2 and modern packages. Use this skill when creating or improving graphs for housing data analysis (price distributions, correlations, geographic maps, property comparisons). Addresses UX/Data Science critiques of base R graphics with accessible, colorblind-friendly, aesthetically professional visualizations. Supports both static (publication) and interactive (presentation) outputs.
---

# Professional Real Estate Data Visualization in R

## Overview

Transform basic, dated base R graphics into modern, publication-ready visualizations for real estate data analysis. This skill teaches the Grammar of Graphics approach using ggplot2 and related packages to create professional, accessible, and aesthetically pleasing graphs that meet UX and Data Science standards.

**Use this skill when:**
- Creating visualizations for housing/real estate data
- Replacing base R plots (hist, plot, boxplot) with professional alternatives
- Need publication-ready graphs for academic papers or client reports
- Improving aesthetics and accessibility of existing visualizations
- Creating interactive visualizations for presentations or exploration

## The Problem with Base R Graphics

### Common UX/Data Science Critiques

**Aesthetic Issues:**
- Dated appearance ("throwback to dawn of R era")
- Poor default styling - looks unprofessional
- Inconsistent quality across platforms
- Difficult to polish for publications

**Functional Limitations:**
- No automatic legend generation
- Procedural approach (step-by-step) vs declarative (what you want)
- Limited faceting and grouping capabilities
- Inflexible theming - changes not reusable
- No built-in statistical layers

**Professional Standards:**
- Not publication-ready by default
- Poor typography and text formatting
- No colorblind-friendly palettes
- Requires extensive manual customization

### The Modern Alternative: ggplot2 + Ecosystem

**Grammar of Graphics approach:**
- Declarative: Describe what you want, not how to draw it
- Layered: Build complexity incrementally
- Consistent: Same principles across all plot types
- Composable: Easily combine multiple visualizations

**Key advantages:**
- Publication-ready defaults
- Automatic legends and scales
- Colorblind-friendly palettes built-in
- Professional typography
- Statistical layers (regression lines, confidence intervals)
- Easy theming and customization

## Required Packages

### Core Visualization Stack

```r
# Install if needed
install.packages(c("ggplot2", "scales", "viridis", "ggpubr", "patchwork"))

# Load packages
library(ggplot2)   # Grammar of Graphics
library(scales)    # Professional formatting
library(viridis)   # Colorblind-friendly palettes
library(ggpubr)    # Publication themes
library(patchwork) # Multi-plot layouts
```

### Optional Enhancements

```r
# For specialized visualizations
install.packages(c("ggridges", "ggcorrplot", "plotly", "sf"))

library(ggridges)   # Distribution comparisons (ridgeline plots)
library(ggcorrplot) # Correlation matrices
library(plotly)     # Interactive visualizations
library(sf)         # Geographic/spatial data
```

## Quick Start: Before & After

### Base R (What Not to Do)

```r
# Ugly, dated, unprofessional
hist(housing$SalePrice)
plot(housing$GrLivArea, housing$SalePrice)
boxplot(SalePrice ~ Neighborhood, data = housing)
```

**Problems:** Poor aesthetics, no dollar formatting, manual legends, dated appearance

### Modern ggplot2 (Professional Alternative)

```r
# Histogram with professional formatting
ggplot(housing, aes(x = SalePrice)) +
  geom_histogram(bins = 30, fill = "steelblue", alpha = 0.7) +
  scale_x_continuous(labels = label_dollar()) +
  labs(title = "Distribution of Sale Prices",
       x = "Sale Price", y = "Count") +
  theme_minimal()

# Scatter plot with regression line
ggplot(housing, aes(x = GrLivArea, y = SalePrice)) +
  geom_point(alpha = 0.4, color = "steelblue") +
  geom_smooth(method = "lm", se = TRUE, color = "darkred") +
  scale_y_continuous(labels = label_dollar()) +
  scale_x_continuous(labels = label_comma()) +
  labs(title = "Price vs. Living Area",
       x = "Living Area (sq ft)", y = "Sale Price") +
  theme_minimal()
```

**Benefits:** Professional aesthetics, automatic formatting, publication-ready, accessible

## Visualization Types for Real Estate Data

## 1. Price Distributions

### Histogram with Density Overlay

**When to use:** Show distribution of sale prices, identify skewness and outliers

```r
ggplot(housing, aes(x = SalePrice)) +
  geom_histogram(aes(y = after_stat(density)),
                 bins = 30,
                 fill = "steelblue",
                 alpha = 0.7) +
  geom_density(color = "darkred", linewidth = 1) +
  scale_x_continuous(labels = label_dollar()) +
  labs(title = "Distribution of Sale Prices",
       subtitle = "Histogram with density overlay",
       x = "Sale Price",
       y = "Density") +
  theme_minimal(base_size = 12)
```

**Key elements:**
- `after_stat(density)` converts counts to density for overlay
- `label_dollar()` formats axis as currency
- `theme_minimal(base_size = 12)` sets clean theme with readable text
- Red density line shows smoothed distribution

### Log-Transformed Distribution

**When to use:** Right-skewed price data (most real estate data)

```r
ggplot(housing, aes(x = SalePrice)) +
  geom_histogram(bins = 40, fill = "steelblue", alpha = 0.7) +
  scale_x_log10(labels = label_dollar()) +
  labs(title = "Distribution of Sale Prices (Log Scale)",
       x = "Sale Price (log scale)",
       y = "Count") +
  theme_pubr()
```

**Why log transform:**
- Makes right-skewed data more normal
- Easier to see patterns across wide price ranges
- Better for identifying outliers

### Ridgeline Plot (Compare Neighborhoods)

**When to use:** Compare price distributions across many neighborhoods simultaneously

```r
library(ggridges)

ggplot(housing, aes(x = SalePrice, y = Neighborhood, fill = Neighborhood)) +
  geom_density_ridges(alpha = 0.7, scale = 2) +
  scale_fill_viridis_d() +
  scale_x_continuous(labels = label_dollar()) +
  labs(title = "Sale Price Distributions by Neighborhood",
       x = "Sale Price",
       y = NULL) +
  theme_ridges() +
  theme(legend.position = "none")  # Colors already identify neighborhoods
```

**Key elements:**
- `geom_density_ridges()` creates overlapping density plots
- `scale = 2` controls amount of overlap
- `scale_fill_viridis_d()` colorblind-friendly discrete colors
- `theme_ridges()` specialized theme for ridgeline plots

## 2. Relationships & Correlations

### Enhanced Scatter Plot

**When to use:** Show relationship between two continuous variables

```r
ggplot(housing, aes(x = GrLivArea, y = SalePrice)) +
  geom_point(alpha = 0.4, color = "steelblue") +
  geom_smooth(method = "lm", se = TRUE, color = "darkred", fill = "pink") +
  scale_y_continuous(labels = label_dollar()) +
  scale_x_continuous(labels = label_comma()) +
  labs(title = "Sale Price vs. Living Area",
       subtitle = "With linear regression line and 95% confidence interval",
       x = "Above Ground Living Area (sq ft)",
       y = "Sale Price") +
  theme_minimal(base_size = 12)
```

**Key elements:**
- `alpha = 0.4` makes points semi-transparent (shows overlapping)
- `geom_smooth(method = "lm")` adds regression line
- `se = TRUE` shows 95% confidence interval
- `label_comma()` formats large numbers with commas

### Faceted Scatter Plot

**When to use:** Compare relationships across categorical groups

```r
ggplot(housing, aes(x = GrLivArea, y = SalePrice, color = PropertyType)) +
  geom_point(alpha = 0.5) +
  geom_smooth(method = "lm", se = FALSE) +
  facet_wrap(~PropertyType, scales = "free") +
  scale_y_continuous(labels = label_dollar()) +
  scale_color_viridis_d() +
  labs(title = "Price vs. Living Area by Property Type",
       x = "Living Area (sq ft)",
       y = "Sale Price") +
  theme_bw() +
  theme(legend.position = "bottom")
```

**Key elements:**
- `facet_wrap(~PropertyType)` creates separate panels
- `scales = "free"` allows different axis ranges per panel
- `scale_color_viridis_d()` colorblind-friendly colors

### Correlation Matrix

**When to use:** Show relationships among many numeric variables

```r
library(ggcorrplot)

# Calculate correlations
cor_vars <- housing %>%
  select(SalePrice, GrLivArea, OverallQual, YearBuilt, TotalBsmtSF, GarageCars)
cor_matrix <- cor(cor_vars, use = "complete.obs")

# Visualize
ggcorrplot(cor_matrix,
           method = "circle",
           type = "lower",
           lab = TRUE,
           lab_size = 3,
           colors = c("#6D9EC1", "white", "#E46726"),
           title = "Correlation Matrix: Housing Variables",
           ggtheme = theme_minimal())
```

**Key elements:**
- `method = "circle"` uses circle size for correlation strength
- `type = "lower"` shows only lower triangle (less redundancy)
- `lab = TRUE` displays correlation coefficients
- Custom colors: blue (negative), white (zero), orange (positive)

## 3. Categorical Comparisons

### Ordered Boxplot

**When to use:** Compare price distributions across categories

```r
library(forcats)  # For fct_reorder

housing %>%
  mutate(Neighborhood = fct_reorder(Neighborhood, SalePrice, median)) %>%
  ggplot(aes(x = Neighborhood, y = SalePrice, fill = Neighborhood)) +
  geom_boxplot(alpha = 0.7, outlier.alpha = 0.3) +
  stat_summary(fun = mean, geom = "point",
               shape = 23, size = 3, fill = "red") +
  scale_y_continuous(labels = label_dollar()) +
  scale_fill_viridis_d(option = "plasma") +
  coord_flip() +
  labs(title = "Sale Price Distribution by Neighborhood",
       subtitle = "Ordered by median price. Red diamond = mean.",
       x = NULL,
       y = "Sale Price") +
  theme_minimal() +
  theme(legend.position = "none")
```

**Key elements:**
- `fct_reorder()` orders categories by median price
- `stat_summary()` adds mean marker (red diamond)
- `coord_flip()` makes horizontal for readability
- `outlier.alpha = 0.3` de-emphasizes outliers
- `legend.position = "none"` removes redundant legend

### Violin Plot with Boxplot

**When to use:** Show full distribution shape, not just quartiles

```r
ggplot(housing, aes(x = PropertyType, y = SalePrice, fill = PropertyType)) +
  geom_violin(alpha = 0.6) +
  geom_boxplot(width = 0.2, alpha = 0.8, outlier.shape = NA) +
  scale_y_log10(labels = label_dollar()) +
  scale_fill_viridis_d() +
  labs(title = "Price Distribution by Property Type",
       subtitle = "Violin plot shows distribution shape, boxplot shows quartiles",
       x = NULL,
       y = "Sale Price (log scale)") +
  theme_pubr() +
  theme(legend.position = "none")
```

**Key elements:**
- `geom_violin()` shows full distribution shape
- `geom_boxplot()` overlaid for quartile information
- `width = 0.2` makes boxplot narrow to fit inside violin
- Log scale for wide price ranges

### Bar Chart with Error Bars

**When to use:** Compare means across categories with uncertainty

```r
housing %>%
  group_by(Neighborhood) %>%
  summarize(mean_price = mean(SalePrice),
            se = sd(SalePrice) / sqrt(n())) %>%
  ggplot(aes(x = fct_reorder(Neighborhood, mean_price), y = mean_price)) +
  geom_col(fill = "steelblue") +
  geom_errorbar(aes(ymin = mean_price - 2*se,
                    ymax = mean_price + 2*se),
                width = 0.3,
                linewidth = 0.7) +
  scale_y_continuous(labels = label_dollar()) +
  coord_flip() +
  labs(title = "Mean Sale Price by Neighborhood",
       subtitle = "Error bars show ±2 standard errors (95% CI approx.)",
       x = NULL,
       y = "Mean Sale Price") +
  theme_minimal()
```

**Key elements:**
- Calculate standard error: `sd() / sqrt(n())`
- `geom_col()` for bar chart
- `geom_errorbar()` shows uncertainty (2 SE ≈ 95% CI)
- Ordered by mean price for clarity

## 4. Geographic/Location Data

### Choropleth Map

**When to use:** Show geographic patterns in housing data

```r
library(sf)

# Load spatial data
neighborhoods_sf <- st_read("neighborhoods.shp")

# Calculate median price by neighborhood
price_summary <- housing %>%
  group_by(neighborhood_id) %>%
  summarize(median_price = median(SalePrice))

# Join and plot
neighborhoods_sf %>%
  left_join(price_summary, by = c("ID" = "neighborhood_id")) %>%
  ggplot() +
  geom_sf(aes(fill = median_price), color = "white", linewidth = 0.3) +
  scale_fill_viridis_c(labels = label_dollar(),
                       option = "magma",
                       name = "Median\nPrice") +
  labs(title = "Median Home Prices by Neighborhood",
       subtitle = "Ames, Iowa Housing Data") +
  theme_void() +
  theme(plot.title = element_text(size = 14, face = "bold"),
        legend.position = "right")
```

**Key elements:**
- `geom_sf()` handles geographic data
- `theme_void()` removes axes (appropriate for maps)
- `option = "magma"` good for heat maps
- White borders between regions for clarity

## 5. Multi-Plot Layouts

### Combining Multiple Plots

**When to use:** Create publication figure with multiple panels

```r
library(patchwork)

# Create individual plots
p1 <- ggplot(housing, aes(x = SalePrice)) +
  geom_histogram(bins = 30, fill = "steelblue") +
  scale_x_continuous(labels = label_dollar()) +
  labs(title = "A) Price Distribution") +
  theme_minimal()

p2 <- ggplot(housing, aes(x = GrLivArea, y = SalePrice)) +
  geom_point(alpha = 0.3) +
  geom_smooth(method = "lm") +
  scale_y_continuous(labels = label_dollar()) +
  labs(title = "B) Price vs. Living Area") +
  theme_minimal()

p3 <- ggplot(housing, aes(x = OverallQual, y = SalePrice)) +
  geom_boxplot(aes(group = OverallQual), fill = "lightblue") +
  scale_y_continuous(labels = label_dollar()) +
  labs(title = "C) Price vs. Quality") +
  theme_minimal()

p4 <- ggplot(housing, aes(x = YearBuilt, y = SalePrice)) +
  geom_point(alpha = 0.3, color = "darkgreen") +
  geom_smooth(method = "loess") +
  scale_y_continuous(labels = label_dollar()) +
  labs(title = "D) Price vs. Year Built") +
  theme_minimal()

# Combine with patchwork
(p1 + p2) / (p3 + p4) +
  plot_annotation(title = "Ames Housing Analysis: Key Relationships",
                  theme = theme(plot.title = element_text(size = 16, face = "bold")))
```

**Key elements:**
- `+` combines plots horizontally
- `/` stacks plots vertically
- `plot_annotation()` adds overall title
- Consistent theme across all panels

## Professional Polish

## Themes

### Built-in ggplot2 Themes

```r
theme_minimal()    # Clean, contemporary (RECOMMENDED for most uses)
theme_bw()         # High-contrast black and white
theme_classic()    # Traditional with axis lines
theme_light()      # Light gray lines and axes
theme_dark()       # Dark background (use sparingly)
```

**Text sizes:**
- `theme_minimal(base_size = 12)` for publications/documents
- `theme_minimal(base_size = 16)` for presentations/slides

### Publication Themes (ggpubr)

```r
library(ggpubr)

theme_pubr()       # Publication-ready, clean
theme_pubclean()   # Minimal with no axis lines
theme_classic2()   # Classic with axis lines
```

### Custom Theme Example

```r
# Create custom theme for consistency across all plots
my_housing_theme <- function() {
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", size = 14),
    plot.subtitle = element_text(color = "gray40", size = 11),
    axis.title = element_text(face = "bold", size = 11),
    legend.position = "bottom",
    panel.grid.minor = element_blank()
  )
}

# Use across all plots
ggplot(...) + geom_point() + my_housing_theme()
```

## Color Accessibility

### Viridis Palettes (RECOMMENDED)

**Colorblind-friendly, perceptually uniform, print-safe**

```r
# Continuous variables (prices, areas)
scale_fill_viridis_c(option = "viridis")   # Default, blue-green-yellow
scale_fill_viridis_c(option = "magma")     # Purple-red-yellow (heat maps)
scale_fill_viridis_c(option = "plasma")    # Purple-orange-yellow
scale_fill_viridis_c(option = "inferno")   # Black-red-yellow
scale_fill_viridis_c(option = "cividis")   # Optimized for colorblindness

# Categorical variables (property types, neighborhoods)
scale_fill_viridis_d()                     # Discrete version
scale_color_viridis_d()                    # For point/line colors
```

### ColorBrewer Palettes

```r
# Qualitative (categorical, unordered)
scale_fill_brewer(palette = "Set2")        # Colorblind-friendly
scale_fill_brewer(palette = "Dark2")       # High contrast

# Sequential (ordered, one direction)
scale_fill_brewer(palette = "Blues")       # Light to dark blue
scale_fill_brewer(palette = "YlOrRd")      # Yellow-Orange-Red

# Diverging (ordered, two directions from middle)
scale_fill_brewer(palette = "RdBu")        # Red-White-Blue
scale_fill_brewer(palette = "PiYG")        # Pink-White-Green
```

### Accessibility Checklist

- [ ] Use colorblind-friendly palettes (viridis, ColorBrewer qualitative)
- [ ] Ensure sufficient contrast (test in grayscale)
- [ ] Don't rely solely on color (use shapes, sizes, facets)
- [ ] Readable text sizes (minimum 12pt)
- [ ] Avoid red-green combinations
- [ ] Test with colorblindness simulator

## Formatting Numbers

### Currency (Sale Prices)

```r
scale_y_continuous(labels = label_dollar())           # $250,000
scale_y_continuous(labels = label_dollar(prefix = "£"))  # £250,000
scale_y_continuous(labels = label_dollar(suffix = "K", scale = 1e-3))  # 250K
```

### Large Numbers (Square Footage)

```r
scale_x_continuous(labels = label_comma())            # 1,500
scale_x_continuous(labels = label_number(suffix = " sq ft"))  # 1,500 sq ft
```

### Percentages

```r
scale_y_continuous(labels = label_percent())          # 15%
scale_y_continuous(labels = label_percent(accuracy = 0.1))  # 15.5%
```

## Interactive Visualizations

### Converting ggplot to Interactive

**When to use:** Presentations, exploration, client meetings

```r
library(plotly)

# Create ggplot
p <- ggplot(housing, aes(x = GrLivArea, y = SalePrice,
                         text = paste("Address:", Address,
                                    "<br>Price:", dollar(SalePrice),
                                    "<br>Area:", comma(GrLivArea), "sq ft"))) +
  geom_point(alpha = 0.5, color = "steelblue") +
  scale_y_continuous(labels = label_dollar()) +
  scale_x_continuous(labels = label_comma()) +
  theme_minimal()

# Convert to interactive
ggplotly(p, tooltip = "text")
```

**Benefits:**
- Hover for details
- Zoom and pan
- Click to highlight
- No code changes needed

### Static vs Interactive Decision

**Use Static (ggplot2) when:**
- Academic publications
- PDF reports
- Printed materials
- Long-term archival
- Exact reproducibility needed

**Use Interactive (plotly) when:**
- Exploratory analysis
- Web-based presentations
- Client demonstrations
- HTML reports
- Training materials
- Many data points (hover reveals details)

## Saving Visualizations

### High-Quality Static Outputs

```r
# Save last plot
ggsave("housing_prices.pdf", width = 8, height = 6, units = "in", dpi = 300)
ggsave("housing_prices.png", width = 8, height = 6, units = "in", dpi = 300)

# Save specific plot
ggsave("my_plot.pdf", plot = p1, width = 10, height = 7)
```

**Recommended settings:**
- **Publications**: PDF, 8×6 inches, 300 dpi
- **Presentations**: PNG, 10×7 inches, 300 dpi
- **Web**: PNG, 8×5 inches, 150 dpi

### Interactive Outputs

```r
library(htmlwidgets)

# Save interactive plot
saveWidget(ggplotly(p), "interactive_plot.html")
```

## Common Visualization Tasks

### Quick Reference

**"Replace my histogram with a professional version"**
```r
# Base R
hist(housing$SalePrice)

# ggplot2
ggplot(housing, aes(x = SalePrice)) +
  geom_histogram(bins = 30, fill = "steelblue", alpha = 0.7) +
  scale_x_continuous(labels = label_dollar()) +
  labs(title = "Distribution of Sale Prices", x = "Sale Price", y = "Count") +
  theme_minimal()
```

**"Create a correlation matrix visualization"**
```r
library(ggcorrplot)
cor_matrix <- cor(housing %>% select_if(is.numeric), use = "complete.obs")
ggcorrplot(cor_matrix, method = "circle", type = "lower", lab = TRUE)
```

**"Make a scatter plot with regression line"**
```r
ggplot(housing, aes(x = GrLivArea, y = SalePrice)) +
  geom_point(alpha = 0.4) +
  geom_smooth(method = "lm", se = TRUE) +
  scale_y_continuous(labels = label_dollar()) +
  theme_minimal()
```

**"Compare distributions across groups"**
```r
# Boxplot
ggplot(housing, aes(x = PropertyType, y = SalePrice, fill = PropertyType)) +
  geom_boxplot() +
  scale_y_continuous(labels = label_dollar()) +
  scale_fill_viridis_d() +
  theme_minimal()

# Ridgeline plot (better for many groups)
library(ggridges)
ggplot(housing, aes(x = SalePrice, y = Neighborhood)) +
  geom_density_ridges() +
  scale_x_continuous(labels = label_dollar()) +
  theme_ridges()
```

**"Create a multi-plot figure for publication"**
```r
library(patchwork)
(plot1 + plot2) / (plot3 + plot4) +
  plot_annotation(title = "Figure 1: Housing Analysis Results")
```

## Reference Files

This skill includes detailed reference documentation:

### references/ggplot2_cheatsheet.md
Quick syntax reference for ggplot2:
- Common geoms and their uses
- Scale transformations
- Theme customization
- Positioning and layout

### references/color_palettes.md
Complete guide to accessible color palettes:
- Viridis family (all 8 options)
- ColorBrewer palettes
- Accessibility testing
- When to use each palette type

### references/real_estate_examples.md
Full working examples for real estate visualizations:
- Complete code with explanations
- Before/after comparisons with base R
- Annotated examples for each visualization type
- Tips for specific housing data challenges

## Best Practices Checklist

Before considering a visualization complete:

**Aesthetics:**
- [ ] Uses colorblind-friendly palette (viridis or similar)
- [ ] Has clear, descriptive title
- [ ] Axis labels include units (dollars, sq ft, etc.)
- [ ] Text is readable (minimum 12pt)
- [ ] Consistent theme across related plots

**Data Presentation:**
- [ ] Appropriate plot type for data (continuous vs categorical)
- [ ] Proper scale transformations (log for skewed data)
- [ ] No misleading axis ranges
- [ ] Statistical layers where appropriate (regression, CI)

**Professional Polish:**
- [ ] Currency formatted with dollar signs
- [ ] Large numbers have comma separators
- [ ] Legend positioned appropriately (or removed if redundant)
- [ ] Sufficient contrast for printing/projection
- [ ] Saved at appropriate resolution (300 dpi for publication)

**Accessibility:**
- [ ] Works in grayscale
- [ ] Doesn't rely on color alone
- [ ] Sufficient contrast ratios
- [ ] Text alternatives for key findings

## Integration with housing-analysis-r Skill

This visualization skill complements the housing-analysis-r skill:

- **housing-analysis-r**: Provides statistical analysis workflow (data loading, preprocessing, regression, diagnostics)
- **real-estate-viz-r**: Provides professional visualization of results

**Workflow:**
1. Use housing-analysis-r to perform statistical analysis
2. Identify base R plots that need improvement
3. Use real-estate-viz-r to create publication-quality versions
4. Demonstrate prompt engineering: "improve this visualization using modern best practices"

## Getting Help

**ggplot2 resources:**
- Official documentation: `?ggplot2`
- Cheatsheet: https://rstudio.github.io/cheatsheets/data-visualization.pdf
- Gallery: https://r-graph-gallery.com/

**Color resources:**
- Viridis: https://cran.r-project.org/web/packages/viridis/
- ColorBrewer: https://colorbrewer2.org/
- Colorblind simulator: https://www.color-blindness.com/coblis-color-blindness-simulator/

**Common error solutions:**
- "object not found": Check package loaded with `library()`
- "continuous value supplied to discrete scale": Using wrong scale type
- "Removed N rows containing missing values": Add `na.rm = TRUE` or handle missing data
