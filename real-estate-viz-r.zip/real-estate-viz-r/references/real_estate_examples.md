# Complete Real Estate Visualization Examples

This file contains full working examples for common real estate data visualization tasks, with before/after comparisons showing the improvement from base R to modern ggplot2.

## Example Dataset Structure

Assume a housing dataset with these variables:

```r
housing <- data.frame(
  SalePrice = ...,        # Sale price in dollars
  GrLivArea = ...,        # Above ground living area (sq ft)
  OverallQual = ...,      # Overall quality rating (1-10)
  YearBuilt = ...,        # Year built
  Neighborhood = ...,     # Neighborhood name
  PropertyType = ...,     # House, Condo, Townhouse, etc.
  TotalBsmtSF = ...,      # Total basement square feet
  GarageCars = ...,       # Garage capacity
  Latitude = ...,         # Geographic coordinates
  Longitude = ...
)
```

---

## Example 1: Price Distribution

### The Problem (Base R)

```r
# Base R version - dated, unprofessional
hist(housing$SalePrice,
     main = "Sale Price Distribution",
     xlab = "Price")
```

**Issues:**
- Dated appearance
- No dollar formatting on axis
- Poor default colors
- No density overlay option
- Hard to customize aesthetically

### The Solution (ggplot2)

```r
library(ggplot2)
library(scales)

# Modern, professional version
ggplot(housing, aes(x = SalePrice)) +
  geom_histogram(aes(y = after_stat(density)),
                 bins = 30,
                 fill = "steelblue",
                 alpha = 0.7,
                 color = "white") +
  geom_density(color = "darkred",
               linewidth = 1.2) +
  scale_x_continuous(labels = label_dollar(),
                     breaks = seq(0, 500000, 100000)) +
  labs(title = "Distribution of Sale Prices",
       subtitle = "Ames, Iowa Housing Data (2006-2010)",
       x = "Sale Price",
       y = "Density",
       caption = "Source: Ames Housing Dataset") +
  theme_minimal(base_size = 12) +
  theme(plot.title = element_text(face = "bold", size = 14),
        plot.subtitle = element_text(color = "gray40"))
```

**Improvements:**
✅ Professional appearance
✅ Dollar-formatted axis
✅ Density overlay shows distribution shape
✅ Clear title and subtitle
✅ Publication-ready

### Advanced: Log-Transformed for Skewed Data

```r
# When prices are right-skewed
ggplot(housing, aes(x = SalePrice)) +
  geom_histogram(bins = 40, fill = "steelblue", alpha = 0.7) +
  scale_x_log10(labels = label_dollar(),
                breaks = c(50000, 100000, 200000, 400000)) +
  annotation_logticks(sides = "b") +  # Add log tick marks
  labs(title = "Distribution of Sale Prices (Log Scale)",
       subtitle = "Log transformation reveals detail across price ranges",
       x = "Sale Price (log scale)",
       y = "Count") +
  theme_pubr()
```

---

## Example 2: Price vs. Living Area Scatter Plot

### The Problem (Base R)

```r
# Base R version
plot(housing$GrLivArea, housing$SalePrice,
     main = "Price vs Living Area",
     xlab = "Living Area",
     ylab = "Price")
abline(lm(SalePrice ~ GrLivArea, data = housing), col = "red")
```

**Issues:**
- No transparency (overlapping points hidden)
- Manual regression line
- No confidence interval
- Poor formatting
- Difficult to add groups/colors

### The Solution (ggplot2)

```r
library(ggplot2)
library(scales)

# Modern version with all bells and whistles
ggplot(housing, aes(x = GrLivArea, y = SalePrice)) +
  # Points with transparency
  geom_point(alpha = 0.4,
             color = "steelblue",
             size = 2) +
  # Regression line with confidence interval
  geom_smooth(method = "lm",
              se = TRUE,
              color = "darkred",
              fill = "pink",
              alpha = 0.3) +
  # Professional axis formatting
  scale_y_continuous(labels = label_dollar(),
                     limits = c(0, 600000)) +
  scale_x_continuous(labels = label_comma(),
                     breaks = seq(0, 5000, 1000)) +
  # Labels
  labs(title = "Sale Price vs. Above Ground Living Area",
       subtitle = "Linear regression with 95% confidence interval",
       x = "Above Ground Living Area (sq ft)",
       y = "Sale Price",
       caption = "Each point represents one home sale") +
  # Theme
  theme_minimal(base_size = 12) +
  theme(plot.title = element_text(face = "bold"),
        panel.grid.minor = element_blank())
```

**Improvements:**
✅ Transparency shows density
✅ Automatic regression line and CI
✅ Professional formatting
✅ Clear axis labels with units
✅ Informative subtitle

### Advanced: Faceted by Property Type

```r
ggplot(housing, aes(x = GrLivArea, y = SalePrice, color = PropertyType)) +
  geom_point(alpha = 0.5, size = 1.5) +
  geom_smooth(method = "lm", se = FALSE, linewidth = 1) +
  facet_wrap(~PropertyType, scales = "free", ncol = 2) +
  scale_y_continuous(labels = label_dollar()) +
  scale_x_continuous(labels = label_comma()) +
  scale_color_viridis_d(option = "plasma") +
  labs(title = "Price vs. Living Area by Property Type",
       subtitle = "Each property type shows different price-per-square-foot patterns",
       x = "Living Area (sq ft)",
       y = "Sale Price") +
  theme_bw(base_size = 11) +
  theme(legend.position = "none",  # Redundant with facet labels
        strip.background = element_rect(fill = "lightblue"))
```

---

## Example 3: Neighborhood Price Comparison

### The Problem (Base R)

```r
# Base R version
boxplot(SalePrice ~ Neighborhood, data = housing,
        main = "Price by Neighborhood",
        las = 2)  # Rotate labels
```

**Issues:**
- Unordered neighborhoods (alphabetical)
- No color differentiation
- Cramped labels
- No professional polish
- Can't easily add mean markers

### The Solution (ggplot2)

```r
library(ggplot2)
library(scales)
library(forcats)  # For fct_reorder
library(dplyr)

# Professional ordered boxplot
housing %>%
  mutate(Neighborhood = fct_reorder(Neighborhood, SalePrice, median)) %>%
  ggplot(aes(x = Neighborhood, y = SalePrice, fill = Neighborhood)) +
  # Boxplot
  geom_boxplot(alpha = 0.7,
               outlier.alpha = 0.3,
               outlier.color = "red") +
  # Add mean marker (diamond)
  stat_summary(fun = mean,
               geom = "point",
               shape = 23,
               size = 3,
               fill = "red",
               color = "darkred") +
  # Formatting
  scale_y_continuous(labels = label_dollar(),
                     limits = c(0, 500000)) +
  scale_fill_viridis_d(option = "turbo") +
  coord_flip() +
  # Labels
  labs(title = "Sale Price Distribution by Neighborhood",
       subtitle = "Ordered by median price. Red diamond indicates mean.",
       x = NULL,
       y = "Sale Price",
       caption = "Outliers shown as individual points") +
  # Theme
  theme_minimal(base_size = 12) +
  theme(legend.position = "none",  # Colors are just for aesthetics
        plot.title = element_text(face = "bold"),
        panel.grid.major.y = element_blank())
```

**Improvements:**
✅ Neighborhoods ordered by median price
✅ Colorful, visually appealing
✅ Easy to read (horizontal)
✅ Shows both mean and median
✅ Professional appearance

### Alternative: Ridgeline Plot (Better for Many Neighborhoods)

```r
library(ggridges)

ggplot(housing, aes(x = SalePrice, y = Neighborhood, fill = Neighborhood)) +
  geom_density_ridges(alpha = 0.7,
                      scale = 2,
                      rel_min_height = 0.01) +
  scale_fill_viridis_d(option = "plasma") +
  scale_x_continuous(labels = label_dollar(),
                     limits = c(0, 500000)) +
  labs(title = "Sale Price Distributions by Neighborhood",
       subtitle = "Ridgeline plot shows full distribution shape",
       x = "Sale Price",
       y = NULL) +
  theme_ridges(base_size = 12) +
  theme(legend.position = "none")
```

**When to use ridgeline:**
- Many categories (10+)
- Want to see full distribution shape
- Comparing shapes across groups

---

## Example 4: Correlation Matrix

### The Problem (Base R)

```r
# Base R version
cor_vars <- housing[, c("SalePrice", "GrLivArea", "OverallQual",
                        "YearBuilt", "TotalBsmtSF", "GarageCars")]
cor_matrix <- cor(cor_vars, use = "complete.obs")

# Hard to visualize
heatmap(cor_matrix)
```

**Issues:**
- Default heatmap is ugly
- No correlation values shown
- Poor color scheme
- Not intuitive to read

### The Solution (ggcorrplot)

```r
library(ggcorrplot)
library(dplyr)

# Calculate correlations
cor_vars <- housing %>%
  select(SalePrice, GrLivArea, OverallQual, YearBuilt,
         TotalBsmtSF, GarageCars, GarageArea)

cor_matrix <- cor(cor_vars, use = "complete.obs")

# Beautiful correlation matrix
ggcorrplot(cor_matrix,
           method = "circle",           # Circle size shows strength
           type = "lower",               # Show only lower triangle
           lab = TRUE,                   # Show correlation values
           lab_size = 3,
           colors = c("#6D9EC1", "white", "#E46726"),  # Blue-white-orange
           title = "Correlation Matrix: Housing Variables",
           ggtheme = theme_minimal(base_size = 12),
           legend.title = "Correlation")
```

**Improvements:**
✅ Clear visual representation
✅ Shows correlation coefficients
✅ Colorblind-friendly colors
✅ Professional appearance
✅ Easy to identify strong correlations

### Advanced: With Hierarchical Clustering

```r
ggcorrplot(cor_matrix,
           method = "circle",
           type = "lower",
           hc.order = TRUE,              # Order by similarity
           lab = TRUE,
           colors = c("#440154", "white", "#FDE725"),  # Viridis colors
           outline.color = "gray",
           title = "Correlation Matrix (Hierarchically Ordered)",
           ggtheme = theme_minimal())
```

---

## Example 5: Multi-Plot Figure (Publication)

### The Goal

Create a 2×2 figure showing key housing analysis results suitable for academic publication.

### The Solution (patchwork)

```r
library(patchwork)
library(ggplot2)
library(scales)

# Plot 1: Price Distribution
p1 <- ggplot(housing, aes(x = SalePrice)) +
  geom_histogram(bins = 30, fill = "steelblue", alpha = 0.7) +
  scale_x_continuous(labels = label_dollar()) +
  labs(title = "A) Price Distribution",
       x = "Sale Price",
       y = "Count") +
  theme_minimal(base_size = 10)

# Plot 2: Price vs Living Area
p2 <- ggplot(housing, aes(x = GrLivArea, y = SalePrice)) +
  geom_point(alpha = 0.3, color = "steelblue") +
  geom_smooth(method = "lm", se = TRUE, color = "darkred") +
  scale_y_continuous(labels = label_dollar()) +
  scale_x_continuous(labels = label_comma()) +
  labs(title = "B) Price vs. Living Area",
       x = "Living Area (sq ft)",
       y = "Sale Price") +
  theme_minimal(base_size = 10)

# Plot 3: Price vs Quality
p3 <- ggplot(housing, aes(x = factor(OverallQual), y = SalePrice)) +
  geom_boxplot(fill = "lightblue", alpha = 0.7) +
  scale_y_continuous(labels = label_dollar()) +
  labs(title = "C) Price vs. Overall Quality",
       x = "Overall Quality (1-10)",
       y = "Sale Price") +
  theme_minimal(base_size = 10)

# Plot 4: Price vs Year Built
p4 <- ggplot(housing, aes(x = YearBuilt, y = SalePrice)) +
  geom_point(alpha = 0.3, color = "darkgreen") +
  geom_smooth(method = "loess", se = TRUE, color = "red") +
  scale_y_continuous(labels = label_dollar()) +
  labs(title = "D) Price vs. Year Built",
       x = "Year Built",
       y = "Sale Price") +
  theme_minimal(base_size = 10)

# Combine into 2x2 grid
final_plot <- (p1 + p2) / (p3 + p4) +
  plot_annotation(
    title = "Figure 1: Ames Housing Analysis - Key Relationships",
    subtitle = "Analysis of 2,930 residential property sales (2006-2010)",
    caption = "Source: Ames Housing Dataset",
    theme = theme(plot.title = element_text(size = 14, face = "bold"),
                  plot.subtitle = element_text(size = 11))
  )

# Display
final_plot

# Save for publication
ggsave("housing_analysis_figure1.pdf",
       plot = final_plot,
       width = 10,
       height = 8,
       units = "in",
       dpi = 300)
```

**Benefits:**
✅ Professional multi-panel figure
✅ Consistent theming across panels
✅ Panel labels (A, B, C, D)
✅ Overall title and caption
✅ Publication-ready output

---

## Example 6: Interactive Visualization

### The Goal

Create an interactive scatter plot where users can hover to see details about each home.

### The Solution (plotly)

```r
library(plotly)
library(ggplot2)
library(scales)

# Create ggplot with custom tooltip text
p <- ggplot(housing,
            aes(x = GrLivArea,
                y = SalePrice,
                text = paste("Address:",  Address,
                           "<br>Price:", dollar(SalePrice),
                           "<br>Area:", comma(GrLivArea), "sq ft",
                           "<br>Quality:", OverallQual,
                           "<br>Year:", YearBuilt,
                           "<br>Neighborhood:", Neighborhood))) +
  geom_point(alpha = 0.5, color = "steelblue", size = 2) +
  scale_y_continuous(labels = label_dollar()) +
  scale_x_continuous(labels = label_comma()) +
  labs(title = "Interactive Housing Price Explorer",
       x = "Living Area (sq ft)",
       y = "Sale Price") +
  theme_minimal()

# Convert to interactive plotly
interactive_plot <- ggplotly(p, tooltip = "text")

# Display
interactive_plot

# Save as HTML
library(htmlwidgets)
saveWidget(interactive_plot, "interactive_housing_prices.html")
```

**Benefits:**
✅ Hover for detailed information
✅ Zoom and pan capabilities
✅ Click to highlight
✅ Great for presentations
✅ Shareable as HTML file

---

## Example 7: Time Series (Sales Over Time)

### The Goal

Show how median housing prices have changed over time.

### The Solution

```r
library(dplyr)
library(lubridate)
library(ggplot2)

# Aggregate by month
monthly_prices <- housing %>%
  mutate(month = floor_date(SaleDate, "month")) %>%
  group_by(month) %>%
  summarize(
    median_price = median(SalePrice),
    lower_quartile = quantile(SalePrice, 0.25),
    upper_quartile = quantile(SalePrice, 0.75),
    n_sales = n()
  )

# Time series plot
ggplot(monthly_prices, aes(x = month, y = median_price)) +
  # Ribbon for IQR
  geom_ribbon(aes(ymin = lower_quartile, ymax = upper_quartile),
              fill = "steelblue",
              alpha = 0.3) +
  # Median line
  geom_line(color = "darkblue",
            linewidth = 1.2) +
  # Points
  geom_point(aes(size = n_sales),
             color = "darkblue",
             alpha = 0.7) +
  # Formatting
  scale_y_continuous(labels = label_dollar()) +
  scale_x_date(date_breaks = "6 months",
               date_labels = "%b %Y") +
  scale_size_continuous(name = "Number\nof Sales",
                       range = c(2, 8)) +
  # Labels
  labs(title = "Housing Price Trends Over Time",
       subtitle = "Median price with interquartile range. Point size shows sale volume.",
       x = NULL,
       y = "Median Sale Price",
       caption = "Data: Ames Housing (2006-2010)") +
  # Theme
  theme_minimal(base_size = 12) +
  theme(plot.title = element_text(face = "bold"),
        axis.text.x = element_text(angle = 45, hjust = 1))
```

---

## Example 8: Geographic Visualization (Map)

### The Goal

Create a choropleth map showing median prices by neighborhood.

### The Solution (sf + ggplot2)

```r
library(sf)
library(dplyr)
library(ggplot2)
library(viridis)

# Load spatial data (shapefile or GeoJSON)
neighborhoods_sf <- st_read("data/neighborhoods.shp")

# Calculate median price by neighborhood
price_by_neighborhood <- housing %>%
  group_by(neighborhood_id) %>%
  summarize(
    median_price = median(SalePrice),
    n_sales = n()
  )

# Join spatial data with prices
map_data <- neighborhoods_sf %>%
  left_join(price_by_neighborhood, by = c("ID" = "neighborhood_id"))

# Create choropleth map
ggplot(map_data) +
  geom_sf(aes(fill = median_price),
          color = "white",
          linewidth = 0.3) +
  scale_fill_viridis_c(option = "magma",
                       labels = label_dollar(),
                       name = "Median\nPrice",
                       na.value = "gray90") +
  labs(title = "Median Home Prices by Neighborhood",
       subtitle = "Ames, Iowa (2006-2010)",
       caption = "Source: Ames Housing Dataset") +
  theme_void(base_size = 12) +
  theme(plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
        plot.subtitle = element_text(hjust = 0.5),
        legend.position = "right")
```

**Benefits:**
✅ Geographic context
✅ Immediate visual patterns
✅ Professional cartography
✅ Colorblind-friendly palette
✅ Publication-ready

---

## Tips for Real Estate Visualizations

### 1. Always Format Currency

```r
# Wrong
scale_y_continuous()

# Right
scale_y_continuous(labels = label_dollar())
```

### 2. Use Log Scale for Skewed Prices

```r
# When prices span orders of magnitude
scale_x_log10(labels = label_dollar())
```

### 3. Order Categories Meaningfully

```r
# Wrong: alphabetical
aes(x = Neighborhood)

# Right: ordered by median price
mutate(Neighborhood = fct_reorder(Neighborhood, SalePrice, median))
```

### 4. Show Uncertainty

```r
# Add confidence intervals
geom_smooth(method = "lm", se = TRUE)

# Add error bars
geom_errorbar(aes(ymin = lower, ymax = upper))
```

### 5. Use Appropriate Themes

```r
# Publications
theme_minimal(base_size = 12)

# Presentations
theme_minimal(base_size = 16)
```

### 6. Save at Correct Resolution

```r
# Publication
ggsave("plot.pdf", width = 8, height = 6, dpi = 300)

# Presentation
ggsave("plot.png", width = 10, height = 7, dpi = 300)
```

---

## Complete Analysis Example

Here's a complete workflow from start to finish:

```r
# Load packages
library(tidyverse)   # Data manipulation and ggplot2
library(scales)      # Number formatting
library(viridis)     # Colors
library(patchwork)   # Multi-plot layouts

# Load data
housing <- read_csv("amesHousing2011.csv")

# 1. Explore distribution
p_dist <- ggplot(housing, aes(x = SalePrice)) +
  geom_histogram(bins = 30, fill = "steelblue", alpha = 0.7) +
  scale_x_continuous(labels = label_dollar()) +
  labs(title = "Price Distribution") +
  theme_minimal()

# 2. Key relationship
p_area <- ggplot(housing, aes(x = GrLivArea, y = SalePrice)) +
  geom_point(alpha = 0.3) +
  geom_smooth(method = "lm") +
  scale_y_continuous(labels = label_dollar()) +
  labs(title = "Price vs. Living Area") +
  theme_minimal()

# 3. Categorical comparison
p_qual <- housing %>%
  ggplot(aes(x = factor(OverallQual), y = SalePrice)) +
  geom_boxplot(fill = "lightblue") +
  scale_y_continuous(labels = label_dollar()) +
  labs(title = "Price vs. Quality") +
  theme_minimal()

# 4. Combine and save
final <- (p_dist + p_area) / p_qual +
  plot_annotation(title = "Ames Housing Analysis")

ggsave("housing_analysis.pdf", final, width = 10, height = 8)
```

This example demonstrates the complete modern R visualization workflow for real estate data.
