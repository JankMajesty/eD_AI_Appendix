# ggplot2 Quick Reference for Real Estate Visualization

## Core Concept: Grammar of Graphics

ggplot2 builds plots in layers using a consistent grammar:

```r
ggplot(data, aes(x = var1, y = var2)) +  # Data + Aesthetics
  geom_point() +                          # Geometry (how to display)
  scale_y_continuous() +                   # Scales (axis transformations)
  labs(title = "Title") +                 # Labels
  theme_minimal()                         # Theme (overall appearance)
```

## Basic Structure

### 1. Initialize with Data

```r
ggplot(housing)                      # Just data
ggplot(housing, aes(x = price))      # Data + aesthetic mappings
```

### 2. Add Geometries (geoms)

```r
+ geom_point()                       # Scatter plot
+ geom_line()                        # Line plot
+ geom_histogram()                   # Histogram
+ geom_boxplot()                     # Boxplot
+ geom_bar()                         # Bar chart
+ geom_violin()                      # Violin plot
```

### 3. Customize Scales

```r
+ scale_x_continuous()               # Continuous x-axis
+ scale_y_log10()                    # Log10 y-axis
+ scale_fill_viridis_d()             # Discrete fill colors
+ scale_color_manual(values = c(...))  # Manual color specification
```

### 4. Add Labels

```r
+ labs(
    title = "Main Title",
    subtitle = "Subtitle",
    x = "X Axis Label",
    y = "Y Axis Label",
    caption = "Source: Data source"
  )
```

### 5. Apply Theme

```r
+ theme_minimal()                    # Apply complete theme
+ theme(legend.position = "bottom")  # Customize specific elements
```

## Common Geoms for Real Estate Data

### Distributions

```r
# Histogram
geom_histogram(bins = 30, fill = "steelblue", alpha = 0.7)

# Density plot
geom_density(color = "red", linewidth = 1)

# Boxplot
geom_boxplot(fill = "lightblue", outlier.color = "red")

# Violin plot
geom_violin(alpha = 0.6)
```

### Relationships

```r
# Scatter plot
geom_point(alpha = 0.4, color = "steelblue")

# Line plot
geom_line(color = "darkred", linewidth = 1)

# Smooth/regression line
geom_smooth(method = "lm", se = TRUE, color = "red")

# Loess smooth
geom_smooth(method = "loess", span = 0.3)
```

### Categorical Comparisons

```r
# Bar chart (counts)
geom_bar(fill = "steelblue")

# Column chart (values)
geom_col(fill = "steelblue")

# Error bars
geom_errorbar(aes(ymin = lower, ymax = upper), width = 0.2)
```

### Statistical Layers

```r
# Add mean marker
stat_summary(fun = mean, geom = "point", color = "red", size = 3)

# Add median line
stat_summary(fun = median, geom = "line", color = "blue")
```

## Aesthetic Mappings (aes)

### What Can Be Mapped

```r
aes(
  x = Variable1,                     # X position
  y = Variable2,                     # Y position
  color = Category,                  # Point/line color
  fill = Category,                   # Fill color (bars, areas)
  size = NumericVar,                 # Point/line size
  alpha = NumericVar,                # Transparency
  shape = Category,                  # Point shape
  linetype = Category                # Line type (solid, dashed, etc.)
)
```

### Inside vs Outside aes()

```r
# INSIDE aes() - maps to data variable
geom_point(aes(color = PropertyType))  # Color varies by PropertyType

# OUTSIDE aes() - fixed value for all
geom_point(color = "blue")              # All points blue
```

## Scales

### Continuous Scales

```r
# Linear scale with custom limits and breaks
scale_x_continuous(
  limits = c(0, 500000),
  breaks = seq(0, 500000, 100000),
  labels = label_dollar()
)

# Log10 scale
scale_y_log10(labels = label_dollar())

# Square root scale
scale_x_sqrt()

# Reverse scale
scale_y_reverse()
```

### Discrete Scales

```r
# Manual colors
scale_color_manual(values = c("red", "blue", "green"))

# Reorder factor levels
scale_x_discrete(limits = c("House", "Condo", "Townhouse"))
```

### Date Scales

```r
scale_x_date(
  date_breaks = "6 months",
  date_labels = "%b %Y"              # Jan 2020
)
```

## Formatting with scales Package

### Currency

```r
library(scales)

scale_y_continuous(labels = label_dollar())                    # $250,000
scale_y_continuous(labels = label_dollar(prefix = "€"))        # €250,000
scale_y_continuous(labels = label_dollar(suffix = "K", scale = 1e-3))  # 250K
```

### Numbers

```r
scale_x_continuous(labels = label_comma())                     # 1,500
scale_x_continuous(labels = label_number(suffix = " sq ft"))   # 1,500 sq ft
scale_x_continuous(labels = label_number(scale = 1e-3, suffix = "K"))  # 250K
```

### Percentages

```r
scale_y_continuous(labels = label_percent())                   # 15%
scale_y_continuous(labels = label_percent(accuracy = 0.1))     # 15.5%
```

## Faceting (Small Multiples)

### Facet Wrap

```r
# Create grid of plots by one variable
facet_wrap(~Neighborhood)

# Specify number of columns
facet_wrap(~Neighborhood, ncol = 3)

# Free scales (different axis ranges per panel)
facet_wrap(~Neighborhood, scales = "free")
facet_wrap(~Neighborhood, scales = "free_y")   # Only y-axis free
```

### Facet Grid

```r
# Create grid by two variables (rows ~ columns)
facet_grid(PropertyType ~ Neighborhood)

# Just rows
facet_grid(PropertyType ~ .)

# Just columns
facet_grid(. ~ Neighborhood)

# Free scales
facet_grid(PropertyType ~ Neighborhood, scales = "free")
```

## Coordinates

```r
# Flip x and y axes (make horizontal)
coord_flip()

# Fixed aspect ratio
coord_fixed(ratio = 1)

# Cartesian with limits (zooms without removing data)
coord_cartesian(xlim = c(0, 300000), ylim = c(0, 5000))

# Polar coordinates
coord_polar()
```

## Themes

### Complete Themes

```r
theme_minimal()      # Clean, minimal (RECOMMENDED)
theme_bw()           # Black and white, grid
theme_classic()      # Classic with axes
theme_light()        # Light axes and grid
theme_dark()         # Dark background
theme_void()         # Completely blank (for maps)
```

### Theme with Size

```r
theme_minimal(base_size = 12)    # For documents
theme_minimal(base_size = 16)    # For presentations
```

### Custom Theme Elements

```r
theme(
  # Text elements
  plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
  plot.subtitle = element_text(size = 12, color = "gray50"),
  axis.title = element_text(size = 12, face = "bold"),
  axis.text = element_text(size = 10),

  # Legend
  legend.position = "bottom",          # "top", "bottom", "left", "right", "none"
  legend.title = element_text(face = "bold"),
  legend.background = element_rect(fill = "white", color = "gray"),

  # Panel
  panel.grid.major = element_line(color = "gray90"),
  panel.grid.minor = element_blank(),  # Remove minor grid
  panel.background = element_rect(fill = "white"),

  # Plot background
  plot.background = element_rect(fill = "white", color = NA),

  # Margins
  plot.margin = margin(10, 10, 10, 10)  # top, right, bottom, left
)
```

## Combining Plots (patchwork)

```r
library(patchwork)

# Horizontal combination
plot1 + plot2

# Vertical combination
plot1 / plot2

# Complex layouts
(plot1 + plot2) / plot3

# 2x2 grid
(plot1 + plot2) / (plot3 + plot4)

# Add overall title
(plot1 + plot2) +
  plot_annotation(title = "Overall Title",
                  subtitle = "Overall subtitle")

# Share legend
(plot1 + plot2) +
  plot_layout(guides = "collect")
```

## Color Scales

### Viridis (Recommended)

```r
# Continuous
scale_fill_viridis_c(option = "viridis")   # Blue-green-yellow
scale_fill_viridis_c(option = "magma")     # Purple-red-yellow
scale_fill_viridis_c(option = "plasma")    # Purple-orange-yellow
scale_fill_viridis_c(option = "inferno")   # Black-red-yellow
scale_fill_viridis_c(option = "cividis")   # Colorblind optimized

# Discrete
scale_fill_viridis_d()
scale_color_viridis_d()
```

### ColorBrewer

```r
# Qualitative (categorical)
scale_fill_brewer(palette = "Set2")
scale_fill_brewer(palette = "Dark2")

# Sequential (ordered)
scale_fill_brewer(palette = "Blues")
scale_fill_brewer(palette = "YlOrRd")

# Diverging (centered)
scale_fill_brewer(palette = "RdBu")
scale_fill_brewer(palette = "PiYG")
```

### Manual Colors

```r
scale_fill_manual(values = c("red", "blue", "green"))
scale_color_manual(values = c("#FF0000", "#0000FF", "#00FF00"))
```

## Annotations

### Text Annotations

```r
+ annotate("text",
           x = 100000,
           y = 2000,
           label = "Important point",
           color = "red",
           size = 5)
```

### Shapes

```r
# Rectangle
+ annotate("rect",
           xmin = 50000, xmax = 150000,
           ymin = 1000, ymax = 3000,
           alpha = 0.2, fill = "blue")

# Vertical line
+ geom_vline(xintercept = 100000, linetype = "dashed", color = "red")

# Horizontal line
+ geom_hline(yintercept = 2000, linetype = "dashed", color = "blue")

# Diagonal reference line
+ geom_abline(intercept = 0, slope = 1, linetype = "dashed")
```

## Saving Plots

```r
# Save last plot displayed
ggsave("plot.png", width = 8, height = 6, units = "in", dpi = 300)

# Save specific plot
ggsave("plot.pdf", plot = my_plot, width = 10, height = 7)

# Different formats
ggsave("plot.png")   # PNG
ggsave("plot.pdf")   # PDF (vector, scalable)
ggsave("plot.jpg")   # JPEG
ggsave("plot.svg")   # SVG (vector, web)
```

## Common Patterns for Housing Data

### Price Distribution

```r
ggplot(housing, aes(x = SalePrice)) +
  geom_histogram(bins = 30, fill = "steelblue", alpha = 0.7) +
  scale_x_continuous(labels = label_dollar()) +
  labs(title = "Distribution of Sale Prices",
       x = "Sale Price", y = "Count") +
  theme_minimal()
```

### Price vs Feature with Regression

```r
ggplot(housing, aes(x = LivingArea, y = SalePrice)) +
  geom_point(alpha = 0.4) +
  geom_smooth(method = "lm", se = TRUE, color = "red") +
  scale_y_continuous(labels = label_dollar()) +
  scale_x_continuous(labels = label_comma()) +
  labs(title = "Price vs Living Area",
       x = "Living Area (sq ft)", y = "Sale Price") +
  theme_minimal()
```

### Categorical Comparison

```r
ggplot(housing, aes(x = Neighborhood, y = SalePrice, fill = Neighborhood)) +
  geom_boxplot() +
  scale_y_continuous(labels = label_dollar()) +
  scale_fill_viridis_d() +
  coord_flip() +
  theme_minimal() +
  theme(legend.position = "none")
```

### Faceted by Category

```r
ggplot(housing, aes(x = LivingArea, y = SalePrice)) +
  geom_point(alpha = 0.4) +
  geom_smooth(method = "lm") +
  facet_wrap(~PropertyType) +
  scale_y_continuous(labels = label_dollar()) +
  theme_bw()
```

## Troubleshooting

### Common Errors

**"object not found"**
- Load ggplot2: `library(ggplot2)`
- Check variable names in data

**"Aesthetic must be either length 1 or the same as the data"**
- Using vector of wrong length outside aes()
- Should be inside aes() or single value

**"continuous value supplied to discrete scale"**
- Using discrete scale (scale_x_discrete) with continuous variable
- Use scale_x_continuous instead

**"Removed N rows containing missing values"**
- Data has NA values
- Add `na.rm = TRUE` to geom or filter data

**"Don't know how to automatically pick scale"**
- Missing scale specification for aesthetic
- Add appropriate scale_* function

### Tips

1. **Build incrementally**: Add one layer at a time and check
2. **Store plots**: `p <- ggplot(...) + ...` allows reuse and modification
3. **Use +, not %>%**: ggplot uses `+` to add layers (not pipe `%>%`)
4. **Data first**: Manipulate data with dplyr before plotting
5. **Factor order**: Use `forcats::fct_reorder()` to order categories meaningfully

## Quick Reference Card

| Task | Code |
|------|------|
| Initialize plot | `ggplot(data, aes(x, y))` |
| Add points | `+ geom_point()` |
| Add line | `+ geom_line()` |
| Add bars | `+ geom_col()` |
| Regression line | `+ geom_smooth(method = "lm")` |
| Log scale | `+ scale_y_log10()` |
| Dollar format | `+ scale_y_continuous(labels = label_dollar())` |
| Flip axes | `+ coord_flip()` |
| Facet by var | `+ facet_wrap(~var)` |
| Change theme | `+ theme_minimal()` |
| Hide legend | `+ theme(legend.position = "none")` |
| Save plot | `ggsave("plot.png")` |
