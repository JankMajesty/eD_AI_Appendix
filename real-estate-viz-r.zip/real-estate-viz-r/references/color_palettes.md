# Color Palettes for Accessible Real Estate Visualizations

## Why Color Accessibility Matters

- **8% of men** and **0.5% of women** have some form of color vision deficiency
- **Most common**: Red-green colorblindness (deuteranopia and protanopia)
- **Professional requirement**: Publications and reports must be accessible
- **Print-friendly**: Colors must work when converted to grayscale
- **Perceptual uniformity**: Equal steps in data should appear as equal visual steps

## Recommended: Viridis Family

**Best choice for most visualizations**

###Overview

The viridis package provides 8 perceptually-uniform, colorblind-friendly palettes:

1. **viridis** (default) - Blue → Green → Yellow
2. **magma** - Black → Purple → Red → Yellow
3. **plasma** - Purple → Orange → Yellow
4. **inferno** - Black → Red → Yellow
5. **cividis** - Blue → Yellow (optimized for colorblindness)
6. **mako** - Black → Blue → Green
7. **rocket** - Black → Red → White
8. **turbo** - Blue → Green → Yellow → Red

### Key Benefits

✅ Colorblind-friendly (tested with all types)
✅ Perceptually uniform (equal data steps = equal visual steps)
✅ Print-safe (maintains contrast in grayscale)
✅ Beautiful out of the box
✅ Widely accepted in scientific publications

### When to Use Each Viridis Palette

**viridis (default)**
- General purpose
- Good for any continuous data
- Blue-green-yellow is universally recognizable
- **Use for**: Price heat maps, density plots

**magma**
- High contrast, dramatic
- Dark background to bright highlights
- **Use for**: Heat maps, geographic visualizations, highlighting hot spots

**plasma**
- Similar to magma but more purple
- Vibrant, eye-catching
- **Use for**: Presentation slides, when you need visual impact

**inferno**
- Similar to magma and plasma
- Warm color scheme
- **Use for**: Temperature-like data, intensity maps

**cividis**
- **MOST accessible** - specifically optimized for deuteranopia (most severe colorblindness)
- Blue to yellow
- **Use for**: When maximum accessibility is critical, regulatory submissions

**mako**
- Cool color scheme (blue-green)
- Calming, professional
- **Use for**: Water-related data, calm professional contexts

**rocket**
- Black to red to white
- High contrast
- **Use for**: When you need dramatic contrast

**turbo**
- Rainbow-like but perceptually uniform
- Covers wide color range
- **Use for**: When you need many distinct colors

### Using Viridis in ggplot2

```r
library(viridis)

# Continuous fill (for heatmaps, choropleths)
scale_fill_viridis_c(option = "viridis")   # or "magma", "plasma", etc.

# Continuous color (for points, lines)
scale_color_viridis_c(option = "magma")

# Discrete fill (for categories)
scale_fill_viridis_d(option = "plasma")

# Discrete color
scale_color_viridis_d(option = "cividis")

# Customize
scale_fill_viridis_c(
  option = "magma",
  direction = -1,        # Reverse color direction
  begin = 0.2,           # Start at 20% of scale
  end = 0.9,             # End at 90% of scale
  alpha = 0.8            # Transparency
)
```

### Examples for Real Estate

```r
# Price heat map (geographic)
ggplot() +
  geom_sf(aes(fill = median_price)) +
  scale_fill_viridis_c(
    option = "magma",
    labels = label_dollar(),
    name = "Median\nPrice"
  )

# Price by neighborhood (categorical)
ggplot(housing, aes(x = Neighborhood, y = SalePrice, fill = Neighborhood)) +
  geom_boxplot() +
  scale_fill_viridis_d(option = "plasma") +
  theme(legend.position = "none")

# Correlation matrix
ggcorrplot(cor_matrix, colors = c("#440154", "white", "#FDE725"))  # Viridis endpoints
```

## ColorBrewer Palettes

**Excellent alternative, widely used in cartography**

### Three Types

1. **Qualitative**: For categories (property types, neighborhoods)
2. **Sequential**: For ordered data in one direction (low to high prices)
3. **Diverging**: For data with meaningful midpoint (above/below average)

### Qualitative Palettes (Categorical Data)

**Best for**: Property types, neighborhoods, regions

```r
# Colorblind-friendly qualitative palettes
scale_fill_brewer(palette = "Set2")      # 8 colors, pastel, RECOMMENDED
scale_fill_brewer(palette = "Dark2")     # 8 colors, darker
scale_fill_brewer(palette = "Paired")    # 12 colors, pairs of similar hues
scale_fill_brewer(palette = "Set1")      # 9 colors, bright (not colorblind-safe)
```

**Avoid for colorblindness:**
- Set1 (has red-green pairs)
- Accent

**Example:**
```r
ggplot(housing, aes(x = PropertyType, y = SalePrice, fill = PropertyType)) +
  geom_violin() +
  scale_fill_brewer(palette = "Set2") +
  theme_minimal()
```

### Sequential Palettes (Ordered Data)

**Best for**: Price gradients, age of homes, size

**Single hue:**
```r
scale_fill_brewer(palette = "Blues")     # Light blue → Dark blue
scale_fill_brewer(palette = "Greens")
scale_fill_brewer(palette = "Reds")
scale_fill_brewer(palette = "Purples")
```

**Multi-hue:**
```r
scale_fill_brewer(palette = "YlOrRd")    # Yellow → Orange → Red
scale_fill_brewer(palette = "YlGnBu")    # Yellow → Green → Blue
scale_fill_brewer(palette = "PuBuGn")    # Purple → Blue → Green
```

**Example:**
```r
# Choropleth map
ggplot() +
  geom_sf(aes(fill = avg_price)) +
  scale_fill_brewer(palette = "YlOrRd", direction = 1) +
  labs(fill = "Average Price")
```

### Diverging Palettes (Data with Midpoint)

**Best for**: Deviations from average, gains/losses, above/below comparisons

```r
scale_fill_brewer(palette = "RdBu")      # Red → White → Blue
scale_fill_brewer(palette = "RdYlGn")    # Red → Yellow → Green (AVOID - not colorblind-safe)
scale_fill_brewer(palette = "PiYG")      # Pink → White → Green
scale_fill_brewer(palette = "PRGn")      # Purple → White → Green
scale_fill_brewer(palette = "BrBG")      # Brown → White → Blue-Green
```

**Avoid RdYlGn** (red-green) for colorblindness

**Example:**
```r
# Price change from average
housing_summary <- housing %>%
  mutate(price_diff = SalePrice - mean(SalePrice))

ggplot(housing_summary, aes(x = Neighborhood, y = price_diff, fill = price_diff)) +
  geom_col() +
  scale_fill_distiller(palette = "RdBu", direction = 1) +
  labs(fill = "Price Difference\nfrom Mean")
```

### Using ColorBrewer

```r
# Discrete (categorical)
scale_fill_brewer(palette = "Set2")
scale_color_brewer(palette = "Dark2")

# Continuous (with distiller)
scale_fill_distiller(palette = "YlOrRd", direction = 1)
scale_color_distiller(palette = "Blues")

# View all palettes
library(RColorBrewer)
display.brewer.all()

# View colorblind-friendly only
display.brewer.all(colorblindFriendly = TRUE)
```

## Manual Color Scales

### When to Use Manual Colors

- Brand colors required
- Specific client requirements
- Need exact hex codes for consistency
- Very few categories (2-3)

### Creating Manual Scales

```r
# Manual discrete colors
scale_fill_manual(values = c("#E69F00", "#56B4E9", "#009E73"))

# Named categories
scale_fill_manual(
  values = c(
    "House" = "#E69F00",
    "Condo" = "#56B4E9",
    "Townhouse" = "#009E73"
  )
)

# Using predefined palettes
okabe_ito <- c("#E69F00", "#56B4E9", "#009E73", "#F0E442",
               "#0072B2", "#D55E00", "#CC79A7", "#000000")
scale_fill_manual(values = okabe_ito)
```

### Okabe-Ito Palette (R 4.0+)

**Specifically designed for colorblindness**

```r
# Built into R 4.0+
palette.colors(palette = "Okabe-Ito")

# Use in ggplot2
scale_fill_manual(values = unname(palette.colors(palette = "Okabe-Ito")))
```

Colors:
- Orange: #E69F00
- Sky Blue: #56B4E9
- Bluish Green: #009E73
- Yellow: #F0E442
- Blue: #0072B2
- Vermillion: #D55E00
- Reddish Purple: #CC79A7
- Black: #000000

## Gradient Scales

### Two-Color Gradient

```r
# Simple gradient
scale_fill_gradient(low = "white", high = "darkblue")

# With midpoint
scale_fill_gradient2(
  low = "blue",
  mid = "white",
  high = "red",
  midpoint = 200000  # Median price
)
```

### Three-Color Gradient

```r
scale_fill_gradientn(
  colors = c("blue", "white", "red"),
  values = scales::rescale(c(0, 0.5, 1))  # Where colors appear
)
```

## Accessibility Checklist

### Must-Haves

- [ ] **Use colorblind-friendly palette** (viridis, ColorBrewer qualitative, Okabe-Ito)
- [ ] **Test in grayscale** - should still be distinguishable
- [ ] **Sufficient contrast** - WCAG 2.0 recommends 4.5:1 for text, 3:1 for graphics
- [ ] **Don't rely solely on color** - use shapes, patterns, or direct labels too
- [ ] **Avoid red-green combinations** - most common colorblindness

### Testing Tools

**Online simulators:**
- Coblis Color Blindness Simulator: https://www.color-blindness.com/coblis-color-blindness-simulator/
- Color Oracle (desktop app): https://colororacle.org/

**In R:**
```r
# Convert plot to grayscale to test
p + scale_fill_grey()  # Preview in grayscale
```

**Print test:**
- Print visualization in black & white
- Can you still distinguish categories?

## Color Choice Decision Tree

```
START
  │
  ├─ Continuous variable (price, area)?
  │   ├─ One direction (low to high)?
  │   │   └─ Use: viridis, magma, or ColorBrewer sequential
  │   │
  │   └─ Two directions from middle (above/below average)?
  │       └─ Use: scale_fill_gradient2() or ColorBrewer diverging (avoid RdYlGn)
  │
  └─ Categorical variable (property type, neighborhood)?
      ├─ Few categories (<8)?
      │   └─ Use: viridis_d, ColorBrewer Set2, or Okabe-Ito
      │
      └─ Many categories (>8)?
          └─ Use: viridis_d (can handle 20+) or facet instead
```

## Recommended Defaults for Real Estate

### Price Visualizations

**Continuous (heat maps, gradients):**
```r
scale_fill_viridis_c(option = "magma", labels = label_dollar())
```

**Diverging (above/below average):**
```r
scale_fill_gradient2(low = "blue", mid = "white", high = "red",
                     midpoint = median(housing$SalePrice),
                     labels = label_dollar())
```

### Property Type/Category

**Discrete categories:**
```r
scale_fill_viridis_d(option = "plasma")
# or
scale_fill_brewer(palette = "Set2")
```

### Neighborhood Comparisons

**Many neighborhoods:**
```r
scale_fill_viridis_d(option = "turbo")  # Handles many categories
```

**Few neighborhoods:**
```r
scale_fill_brewer(palette = "Set2")
```

### Geographic Maps

**Choropleth (continuous values):**
```r
scale_fill_viridis_c(option = "magma", labels = label_dollar())
```

**Regions (categorical):**
```r
scale_fill_viridis_d()
```

## Common Mistakes to Avoid

❌ **Red-green combinations** - Not accessible to most colorblind individuals
❌ **Rainbow color scheme** (jet, rainbow) - Not perceptually uniform
❌ **Too many colors** (>12) - Hard to distinguish, use faceting instead
❌ **Color alone** - Always use additional encodings (shape, size, direct labels)
❌ **Poor contrast** - Light colors on light background
❌ **No legend** - Always label what colors mean

## Quick Reference Table

| Use Case | Recommended Palette | Code |
|----------|---------------------|------|
| Price heat map | Viridis magma | `scale_fill_viridis_c(option = "magma")` |
| Property types (few) | ColorBrewer Set2 | `scale_fill_brewer(palette = "Set2")` |
| Property types (many) | Viridis discrete | `scale_fill_viridis_d()` |
| Above/below average | Gradient2 | `scale_fill_gradient2(low="blue", high="red")` |
| Maximum accessibility | Viridis cividis | `scale_fill_viridis_c(option = "cividis")` |
| Neighborhood map | Viridis plasma | `scale_fill_viridis_d(option = "plasma")` |
| Sequential price | ColorBrewer YlOrRd | `scale_fill_brewer(palette = "YlOrRd")` |

## Resources

**Documentation:**
- Viridis: https://cran.r-project.org/web/packages/viridis/vignettes/intro-to-viridis.html
- ColorBrewer: https://colorbrewer2.org/
- ggplot2 scales: https://ggplot2.tidyverse.org/reference/index.html#scales

**Testing:**
- Color Blindness Simulator: https://www.color-blindness.com/coblis-color-blindness-simulator/
- Contrast Checker: https://webaim.org/resources/contrastchecker/

**Theory:**
- "Rainbow Color Map (Still) Considered Harmful" paper
- WCAG 2.0 Color Contrast Guidelines
