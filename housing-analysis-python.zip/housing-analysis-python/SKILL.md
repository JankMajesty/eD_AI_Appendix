---
name: housing-analysis-python
description: Complete Python-based workflow for housing price regression analysis using pandas, statsmodels, and scikit-learn. Handles data preprocessing, outlier removal, variable transformations, progressive model building, diagnostic analysis, and model comparison. Automatically documents to prompts_log.md and conversation_log.md with [PYTHON] markers. Target 80-90% R² with educational explanations for Python beginners.
---

# Housing Price Analysis with Python

## Overview

Comprehensive Python workflow for analyzing housing datasets to build regression models predicting sale prices. Uses pandas for data manipulation, statsmodels for statistical modeling (R-like), and scikit-learn for machine learning approaches. Automatically documents analysis with [PYTHON] markers for assignment tracking

**Use when:** Analyzing housing/real estate data with Python, comparing Python vs R approaches, or when user prefers Python ecosystem.

## Core Workflow

1. **Data Loading & Exploration** → 2. **Preprocessing & Transformation** → 3. **Model Building** → 4. **Diagnostic Analysis** → 5. **Model Refinement** → 6. **Model Comparison** → 7. **Final Selection**

**Target:** Achieve 80-90% R² (5 variables → ~80%, 12 variables → ~90%)

## Required Libraries

```python
import pandas as pd
import numpy as np
from scipy import stats
import statsmodels.formula.api as smf
from sklearn.linear_model import LinearRegression, LassoCV
import seaborn as sns
import matplotlib.pyplot as plt
```

## Automatic Documentation

Mark all Python work with `[PYTHON]`:

**prompts_log.md:** `**Prompt N [PYTHON]:** Load dataset with pandas`

**conversation_log.md:** `### User Prompt N [PYTHON]: ...`

## Quick Start Example

```python
# Load and clean data
housing = pd.read_csv('amesHousing2011.csv')
threshold = housing['SalePrice'].quantile(0.95)
housing_clean = housing[housing['SalePrice'] <= threshold].copy()

# Log transform
housing_clean['LogSalePrice'] = np.log(housing_clean['SalePrice'])

# Build model with statsmodels (R-like)
import statsmodels.formula.api as smf
model = smf.ols('LogSalePrice ~ GrLivArea + OverallQual',
                data=housing_clean).fit()
print(f"R² = {model.rsquared:.4f}")
```

## Key Python vs R Differences

| Task | R | Python |
|------|---|--------|
| Load data | `read.csv()` | `pd.read_csv()` |
| Summary | `summary()` | `.describe()` |
| Regression | `lm()` | `smf.ols().fit()` |
| R² | `summary(m)$r.squared` | `model.rsquared` |
| Diagnostics | `plot(model)` | Manual plots |

## Core Analysis Steps

### Step 1: Data Loading

```python
housing = pd.read_csv('amesHousing2011.csv')
housing.head()  # View first rows
housing.info()  # Data types
housing.describe()  # Summary stats
```

### Step 2: Outlier Removal

```python
threshold = housing['SalePrice'].quantile(0.95)
housing_clean = housing[housing['SalePrice'] <= threshold].copy()
```

### Step 3: Log Transformations

```python
housing_clean['LogSalePrice'] = np.log(housing_clean['SalePrice'])
housing_clean['LogOverallQual'] = np.log(housing_clean['OverallQual'] + 1)
```

### Step 4: Build Progressive Models

```python
# Model 1
m1 = smf.ols('LogSalePrice ~ GrLivArea', data=housing_clean).fit()
print(f"R² = {m1.rsquared:.4f}")

# Model 2
m2 = smf.ols('LogSalePrice ~ GrLivArea + LogOverallQual',
             data=housing_clean).fit()
print(f"R² = {m2.rsquared:.4f}")
```

### Step 5: Diagnostic Plots

```python
fitted = m2.fittedvalues
residuals = m2.resid

# Residuals vs Fitted
plt.scatter(fitted, residuals, alpha=0.5)
plt.axhline(y=0, color='r', linestyle='--')
plt.xlabel('Fitted')
plt.ylabel('Residuals')
plt.title('Residuals vs. Fitted')
plt.show()
```

### Step 6: Compare Models

```python
models = pd.DataFrame({
    'Model': ['m1', 'm2'],
    'R²': [m1.rsquared, m2.rsquared],
    'Adj R²': [m1.rsquared_adj, m2.rsquared_adj]
})
print(models)
```

## Educational Explanations

**pandas:**
- `.read_csv()` - Load data
- `.head()` - First 5 rows
- `.info()` - Data types
- `.describe()` - Summary statistics
- `.corr()` - Correlation matrix

**statsmodels:**
- `smf.ols()` - R-style regression
- `.fit()` - Fit model
- `.summary()` - Detailed output
- `.rsquared` - R² value

**scikit-learn:**
- `LinearRegression()` - Create model
- `.fit(X, y)` - Train
- `.score(X, y)` - R² score

## Code Formatting for Quarto

````markdown
```{python}
import pandas as pd
housing = pd.read_csv('amesHousing2011.csv')
housing.shape
```
````

## References

This skill includes reference documentation:

### references/python_basics.md
pandas, numpy, statsmodels quick reference

### references/workflow_guide.md
Complete step-by-step Python housing analysis workflow

## Integration

- **housing-analysis-python**: Statistical analysis (this skill)
- **real-estate-viz-python**: Professional visualization (seaborn + plotly)

Use this skill for analysis, then improve visualizations with real-estate-viz-python skill.
