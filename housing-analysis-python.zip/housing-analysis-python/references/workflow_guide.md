# Python Housing Analysis Workflow

## Complete Workflow Example

```python
# 1. Load libraries
import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import seaborn as sns
import matplotlib.pyplot as plt

# 2. Load data
housing = pd.read_csv('amesHousing2011.csv')

# 3. Explore
housing.head()
housing.info()
housing.describe()

# 4. Remove outliers
threshold = housing['SalePrice'].quantile(0.95)
housing_clean = housing[housing['SalePrice'] <= threshold].copy()

# 5. Log transforms
housing_clean['LogSalePrice'] = np.log(housing_clean['SalePrice'])
housing_clean['LogOverallQual'] = np.log(housing_clean['OverallQual'] + 1)

# 6. Build models
m1 = smf.ols('LogSalePrice ~ GrLivArea', data=housing_clean).fit()
m2 = smf.ols('LogSalePrice ~ GrLivArea + LogOverallQual',
             data=housing_clean).fit()

# 7. Compare
print(f"Model 1 R² = {m1.rsquared:.4f}")
print(f"Model 2 R² = {m2.rsquared:.4f}")

# 8. Diagnostics
fitted = m2.fittedvalues
residuals = m2.resid

plt.figure(figsize=(10, 6))
plt.scatter(fitted, residuals, alpha=0.5)
plt.axhline(y=0, color='r', linestyle='--')
plt.xlabel('Fitted Values')
plt.ylabel('Residuals')
plt.title('Residuals vs. Fitted')
plt.show()
```

## Target: 80-90% R²
- 5 variables → ~80%
- 12 variables → ~90%
