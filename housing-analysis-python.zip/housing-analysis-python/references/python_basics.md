# Python Basics for Housing Analysis

## pandas Quick Reference

```python
import pandas as pd

# Load data
df = pd.read_csv('file.csv')

# Inspect
df.head()              # First 5 rows
df.tail()              # Last 5 rows
df.info()              # Data types, memory
df.describe()          # Summary statistics
df.shape               # (rows, columns)

# Select columns
df['column']           # Single column
df[['col1', 'col2']]   # Multiple columns

# Filter rows
df[df['Price'] > 100000]
df[(df['Price'] > 100) & (df['Bedrooms'] > 2)]

# Missing data
df.isnull().sum()      # Count missing per column
df.dropna()            # Remove rows with missing
df.fillna(value)       # Fill missing

# Summary
df.groupby('Category').mean()
df.corr()              # Correlation matrix
```

## numpy

```python
import numpy as np

np.log(df['column'])   # Log transform
np.sqrt(df['column'])  # Square root
np.mean(df['column'])  # Mean
np.median(df['column'])# Median
np.std(df['column'])   # Standard deviation
```

## statsmodels (R-like regression)

```python
import statsmodels.formula.api as smf

# Fit model
model = smf.ols('y ~ x1 + x2', data=df).fit()

# View results
print(model.summary())

# Extract values
model.rsquared         # R²
model.rsquared_adj     # Adjusted R²
model.params           # Coefficients
model.pvalues          # P-values
model.fittedvalues     # Predictions
model.resid            # Residuals
```

## scikit-learn (ML approach)

```python
from sklearn.linear_model import LinearRegression

# Prepare data
X = df[['feature1', 'feature2']]
y = df['target']

# Fit
model = LinearRegression()
model.fit(X, y)

# Evaluate
r2 = model.score(X, y)
predictions = model.predict(X)
```
